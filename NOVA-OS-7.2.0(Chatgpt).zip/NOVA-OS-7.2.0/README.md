# NOVA OS 7.2.0 — Desktop Experience Refresh

NOVA OS is a browser-based desktop and terminal simulator designed for Chromebook use. This release focuses on visual consistency, clearer descriptions, keyboard usability, and a more welcoming first-run experience.

## Run it
1. Download and extract the ZIP.
2. Open the `NOVA-OS-7.2.0` folder in `vscode.dev`.
3. Open `index.html` in Chrome.
4. Virtual files are stored in this browser's local storage.

No npm, build step, or external libraries are required.

## What's new in 7.2.0
- Refreshed desktop header, version label, status indicator, spacing, colors, and navigation states.
- Clearer descriptions for Terminal, Files, Editor, System, and Settings.
- Improved keyboard focus indicators and button feedback.
- More readable terminal output while retaining the expanded workspace.
- More helpful first-run guidance and command-help text.
- Reset settings explain what is and is not changed.
- Responsive layout and reduced-motion support.

## Included apps
- **Terminal:** multiple independent sessions, command history, simulated shell commands.
- **Files:** manage the shared virtual filesystem.
- **Editor:** edit virtual text files and share saved changes with terminal sessions.
- **System:** view simulator status and virtual filesystem counts.
- **Settings:** restore starter files and folders.

## Important limitations
This is a **simulation**, not a replacement operating system. The terminal cannot run arbitrary Chromebook commands, open real crosh, install real packages, or inspect real system hardware. Press **Ctrl + Alt + T** on your Chromebook to open crosh separately. NOVA files are browser storage, not actual files on your Chromebook.

## Data and reset behavior
Virtual files are stored using browser `localStorage`. Clearing browser site data may remove them. Reset restores the starter virtual files/folders and clears terminal history; it does not modify ChromeOS.
