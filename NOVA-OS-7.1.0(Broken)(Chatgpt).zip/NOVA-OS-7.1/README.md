# NOVA OS 7.1 — Terminal Tabs + Command Expansion

## Files
- `index.html`
- `style.css`
- `terminal.js`
- `README.md`

## Run on Chromebook
Keep all files in one folder, open the folder in `vscode.dev`, then open `index.html` in Chrome. This is a plain browser project; no Node.js, npm, Python, compiler, or external libraries are required.

## Terminal sessions
- Click `+` to add a terminal (up to 8).
- Each session has independent current directory, command history, and environment variables.
- All sessions share the same virtual files as Files and Editor.
- Click a tab to switch. Click `×` to close a session. One session must remain.

## Command families
General: `help`, `clear`, `history`, `exit`, `about`, `neofetch`, `whoami`, `hostname`, `uname`, `date`, `uptime`, `ps`, `top`, `reboot`
Files: `pwd`, `ls`, `dir`, `cd`, `mkdir`, `touch`, `write`, `cat`, `type`, `head`, `tail`, `wc`, `cp`, `mv`, `rm`, `tree`, `find`, `grep`, `which`
System: `df`, `free`, `env`, `export KEY=value`, `clearenv`, `man`, `systemctl`, `journalctl`, `lsb_release`, `hostnamectl`
Ubuntu/Debian-style simulation: `apt update`, `apt list`, `apt install <package>`
Arch-style simulation: `pacman -Q`, `pacman -S <package>`
ChromeOS/crosh-style simulation: `crosh`, `help_advanced`, `vmc list`, `shell`
Windows-style simulation: `ver`, `systeminfo`, `cls`, `ipconfig`, `tasklist`, `where`
Text: `echo`, `printf`

## Important
Commands imitating crosh, Ubuntu, Arch, or Windows are simulated only. They do not open the real ChromeOS shell, install software, modify the real network, or change your Chromebook. The virtual filesystem is stored in browser `localStorage`, not on your actual disk.


## Real ChromeOS crosh access (important limitation)

A webpage running in Chrome or opened from `vscode.dev` cannot launch, control, or read the built-in ChromeOS crosh terminal. ChromeOS deliberately isolates webpages from system terminals and privileged commands. This project therefore cannot make `ping` execute in real crosh.

To run a real ping test:
1. On your Chromebook, press **Ctrl + Alt + T** to open crosh.
2. Enter `ping example.com` if that command is supported by your ChromeOS environment.
3. Return to NOVA OS separately when finished.

NOVA's `ping` command now explains this limitation instead of pretending to run a real network test. `open-crosh` explains how to open crosh manually. This does not require Developer Mode or weaken Chromebook security.
