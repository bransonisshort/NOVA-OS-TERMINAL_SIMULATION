# NOVA OS 7.2.1 — Expanded Workspace

This Chromebook-friendly browser desktop simulation expands Settings, Editor, System, Terminal, Files, navigation, and everyday usability.

## Launch
1. Extract `NOVA-OS-7.2.1.zip`.
2. Open the `NOVA-OS-7.2.1` folder in `vscode.dev`.
3. Open `index.html` in Chrome or use a local preview workflow.
4. Preferences and virtual files are stored in this browser's local storage.

## Side navigation
- **Workspace:** Terminal, Files, Editor.
- **System:** System overview.
- **Settings subdivisions:** Appearance, Terminal, Editor, Storage & reset.

## Quality-of-life features
- Files can be filtered by path and show a count of matching/total files.
- Editor shows the active virtual path, word/character counts, and save feedback.
- System overview shows virtual file/folder/session counts and approximate text storage.
- Settings include accent color, compact/comfortable density, terminal/editor font size, command help, clear-output, and restore-defaults controls.
- Keyboard focus states and responsive spacing help with navigation.

## Command examples
Use `help` for command groups and `man <command>` for individual descriptions.
- `pwd` — show the current virtual directory.
- `ls -l` — list virtual items.
- `cd /home/nova` — change virtual directory.
- `mkdir projects` — create a virtual folder.
- `touch todo.txt` — create an empty virtual file.
- `cat welcome.txt` — display a virtual text file.
- `find /home/nova welcome` — search virtual paths.
- `grep Welcome /home/nova/welcome.txt` — search a file for matching text.
- `tree /home/nova` — show the virtual directory tree.
- `stat /home/nova/welcome.txt` — inspect a virtual item.
- `basename /home/nova/welcome.txt` / `dirname /home/nova/welcome.txt` — inspect path components.
- `history` — list commands in the current terminal session.
- `history -c` — clear that session's command history.
- `clear` — clear the active terminal display.
- `banner` — show the NOVA version banner.
- `cal` — show current month/year and date.

## Important limitation
NOVA is a browser simulation, not a real OS. Commands operate on virtual files and cannot grant administrator access, run arbitrary Chromebook commands, control crosh, or modify ChromeOS. Use `Ctrl + Alt + T` on a Chromebook to open real crosh separately.
