# NOVA OS 8.0.1 — Maintenance Release

A Chromebook-friendly browser desktop simulation with a capable terminal.
No npm, build step, or external libraries are needed.

## Launch
1. Extract `NOVA-OS-8.0.1.zip`.
2. Open the `NOVA-OS-8.0.1` folder in `vscode.dev` (or any static file server / local preview).
3. Open `index.html` in Chrome (or use a local preview workflow).
4. Files, settings, aliases, and command history are saved in this browser's local storage, so previous workspace data carries over.

## What's new in 8.0.1

This is a focused maintenance release that polishes the 8.0.0 workspace release:

- **Version consistency** — All UI surfaces (boot screen, top bar, dashboard hero, About panel, shell, system files, PWA manifest, and service worker) now report **8.0.1**.
- **Service worker cache bump** — Cache name updated to `nova-os-8.0.1-shell` so returning visitors reliably receive the new assets after an update.
- **Cleaner release notes** — README reorganized so the current version is clear and the 8.0.0 feature set remains documented for reference.
- **No breaking changes** — Virtual filesystem, settings, App Studio cards, themes, and command history continue to load from existing localStorage data.

### Quick verification
```
version
neofetch
about
```

## What's new in 8.0.0 (carried forward)

### Terminal / NovaShell
- **Pipes and redirects:** `ls | grep txt`, `echo hi > a.txt`, `echo yo >> a.txt`.
- **Chaining:** `a ; b`, `a && b`, `a || b`, plus `$?` for the last exit status.
- **Variables:** `export NAME=value` or `NAME=value`, then `$NAME` / `${NAME}`. Quotes, escapes, and `# comments` work.
- **Wildcards:** `ls *.txt`, `rm old-?.log`, `cp *.md backup/`.
- **Aliases** (saved in this browser): `alias ll='ls -l'`, `unalias ll`. Starter aliases: `ll`, `la`, `l`, `..`.
- **History tools:** `!!`, `!3`, `!prefix`, `history 10`, `history -c`. History survives page reloads.
- **Tab completion** for commands, aliases, and paths. **Ctrl + C** cancels `sleep`/`timer`/scripts, **Ctrl + U** clears the line, **Ctrl + L** clears the screen, **Ctrl + D** closes an extra session, **PageUp/PageDown** scroll.
- **Scripts:** `sh script.sh` (also `source`, `bash`) or `sh -c 'echo a; echo b'`.
- Every command supports `--help`, and `man`, `apropos`, `help <group>`, and `commands` make discovery easier.

### New commands (grouped as in `help`)
- **Files:** `append`, `rmdir`, `du`, `file`, `realpath`, `chmod`/`chown` (no-ops), `edit` (also `nano`/`vi`/`vim`/`code`, which open the NOVA Editor), `download`, `upload`, `backup`, `restore`. Improved: `ls -alhR`, `mkdir -p`, `rm -rf`, `cp -r`, `mv` for folders, `cd -`, `cat -n`, `head/tail -n`, `tree -L`, `find -name/-iname/-type`, `touch` multiple files.
- **Text:** `grep -invcFlr` (regex), `sort`, `uniq`, `cut`, `tr`, `sed 's/a/b/g'`, `nl`, `rev`, `tac`, `tee`, `diff`, `seq`, `base64`, `sha256`.
- **System:** `id`, `groups`, `cal` (real calendar), `date +%F`, `printenv`, `unset`, `kill`, `lscpu`, `display`, `locale`, `battery`, `netinfo` (these show only what the browser itself reports), and a new `neofetch` with a logo.
- **Customize:** `theme`, `density`, `font`, `settings`, `open`, `reset`.
- **Productivity:** `todo`, `note`, `calc` (also `expr`/`bc`), `timer`, `random`, `uuid`, `time`, `repeat`.
- **Fun:** `fortune`, `cowsay`, `banner`.
- **Packages:** `apt` (update/list/search/show/install/remove), `pacman`, `dpkg -l`. Installs are recorded only as a simulated list; nothing is downloaded.
- **Windows-style aliases:** `copy`, `move`, `del`, `md`, `rd`, `ren`, `findstr`, plus existing `dir`, `type`, `cls`, `ver`, `systeminfo`, `tasklist`, `where`.

### Desktop apps & workspace
- **Dashboard:** workspace health, storage meter, terminal count, network state, uptime, daily command tip, recent files, and quick-launch controls.
- **App Studio:** create persistent launch cards that route to built-in NOVA areas (safe shortcuts only).
- **Quick Settings:** one-click accent presets, custom accent picker, density selector.
- **Expanded Color Studio:** customize accent, workspace, surface, text, muted text, terminal, terminal text, borders, buttons, success, warning, error, and selection colors. Export/import themes as JSON.
- **Advanced behavior:** adjustable sidebar width, interface roundness, motion level, command-history limit, terminal output limit, startup page, editor autosave preference, and reset confirmation.
- **New shell commands:** `workspace`, `searchall`, `sessioninfo`, `pin`, `clearfilesearch`, `apps`; `open` recognizes dashboard, studio, and visualization.
- Additional personalization: Aurora, Midnight, Neon Grid, and Nebula backgrounds; terminal font presets; classic, minimal, and power-style prompts.

### Terminal 2.0
- Drag tabs to reorder; double-click or right-click a tab to rename.
- Middle-click closes a tab. Right-click also offers pin/unpin, duplicate, and close.
- Toolbar actions for rename, duplicate, close other tabs, and new sessions.
- `tabs list`, `tabs new`, `tabs rename`, `tabs duplicate`, and `tabs close-others`.

### Visualization & Modules
- Visualization page with source selection, syntax-colored preview, line map, and file statistics (`visualize <file>`).
- Modules page for built-in module toggles (`module list|enable|disable`, `plugin list|enable|disable`).

## Quick tour
```
help                       # grouped command guide
neofetch                   # system summary
mkdir -p projects/web && cd projects/web
echo "hello nova" > hi.txt
cat hi.txt | tr a-z A-Z
find /home -name '*.txt'
alias gs='ls -l /system' ; gs
todo add try NOVA 8.0.1 ; todo list
theme green
calc (2+3)*sqrt(16)
workspace info
searchall "nova"
```

## Important limitations
NOVA is a browser simulation, not a real OS. Commands operate on virtual files stored in browser local storage (about 5 MB). They cannot grant administrator access, run arbitrary Chromebook commands, control crosh, install real software, or modify ChromeOS. `ping`, `curl`, and similar network tools are explained but not executed. Use `Ctrl + Alt + T` on a Chromebook to open real crosh separately. Clearing browser site data removes NOVA's saved files, so use `backup` (or `workspace backup`) first if you want a copy.

For reliable local storage and offline/PWA features, serve the folder from a local development server rather than opening `index.html` with `file://`.

## Keyboard shortcuts
- `Ctrl + Shift + P` — open/close Quick Settings.
- `Ctrl + T` — create a new terminal session (when not typing in a form field).
- `Ctrl + 1` through `Ctrl + 9` — switch to a terminal tab by position.
- `Ctrl + S` — save the current Editor file.
- `Tab` — complete terminal commands and paths.
- `↑` / `↓` — browse terminal command history.
- `Ctrl + L` — clear the active terminal display.

## Release verification
The project is pure static HTML/CSS/JS. Open `index.html` (ideally via a local server) and confirm the version appears as 8.0.1 on the boot screen, top bar, dashboard, and via the `version` command.
