# Changelog

## 8.0.1
Added: command palette (Ctrl+K), colour schemes, recycle bin (`trash`), `snapshot`, `doctor`, `bm`/`goto`, `json`, `clip`/`paste`, `whatsnew`, `shortcuts`, terminal Ctrl+R history search, file sorting, editor Tab indentation, PWA icon/manifest.
Improved: batched/flushed storage writes, live readable dashboard uptime, keyboard focus outlines, reduced-motion support.
Fixed: powerline prompt line break, history limit applied to saved history, stale service-worker cache after updates.

## 8.0.0
See README.md.
