# NOVA OS 8.0.1 — Polish, Speed & Power Tools

A Chromebook-friendly browser desktop simulation with a capable terminal. No npm, build step, or external libraries.
8.0.1 is a drop-in upgrade from 8.0.0 (and 7.2.x): your files, settings, aliases, history and App Studio cards carry over.

## Launch
1. Extract `NOVA-OS-8.0.1.zip`.
2. Open the folder in `vscode.dev` (or serve it locally) and open `index.html` in Chrome.
3. For offline/PWA use, serve over `localhost` or HTTPS (service workers do not run from `file://`).

## What's new in 8.0.1

### New
- **Command palette (`Ctrl + K`, or the ⌕ button):** fuzzy-jump to apps, settings sections, files, colour schemes, bookmarks and every shell command. Type `>` first to run a shell command directly (e.g. `>ls -l`).
- **Colour schemes:** `nova`, `midnight`, `forest`, `sunset`, `rose`, `mono`, `contrast` (high contrast). Pick them in Settings → Appearance, Quick settings, the palette, or with `scheme <name>`. Editing any colour switches the label to "custom".
- **Recycle bin:** deleted files (from `rm`, Files, etc.) are kept in a small bin (50 items / ~400 KB). `trash list`, `trash restore <n|path|--all>`, `trash empty` (alias `undelete`). Moves and renames do not clutter it.
- **Snapshots:** `snapshot save|load|list|delete <name>` — up to 5 named copies of your whole workspace, plus an automatic `before-load` so a load can be undone.
- **`doctor [--fix]`:** checks folders, metadata, terminal tabs, out-of-range settings, storage use and system files, and repairs what it can.
- **Bookmarks:** `bm add|list|go|rm` (alias `goto`) for jumping between folders.
- **`json`:** `json pretty|min|keys|get <path> [file]`, also works in pipes: `cat d.json | json get users[0].name`.
- **`clip` / `paste`:** pipe output to and from the browser clipboard.
- **`whatsnew`, `help_81`, `shortcuts`:** release notes and a full key-binding list.
- **Terminal `Ctrl + R`:** reverse-search command history; press again for older matches.
- **Files:** sort by name, recently modified or size. **Editor:** Tab inserts two spaces (Esc then Tab leaves the editor; toggle in Settings → Editor).
- **PWA:** app icon, manifest id/scope, and a smarter service worker.

### Faster
- File-system saves are batched (one write per 200 ms burst) and always flushed when the tab is hidden or closed, so scripts, `repeat` and big redirects no longer rewrite browser storage on every command.

### Fixed
- Powerline prompt style now actually breaks onto two lines (it printed a literal `\n`).
- The "Command history limit" setting now also applies to saved history.
- The offline cache no longer serves stale files after an update (network-first with cache fallback, versioned cache name).
- Dashboard uptime is readable (`1h 2m 3s`) and updates live.
- Added focus outlines for keyboard users and honours the OS "reduce motion" preference.

### Verification
JavaScript passes `node --check`; the app was loaded in headless Chromium and exercised end to end (trash restore, snapshots, doctor, json, clipboard, schemes, palette, Ctrl+R, persistence across reload) with zero console errors.

---

# Earlier release notes (8.0.0 and prior)

A Chromebook-friendly browser desktop simulation with a much more capable terminal.
No npm, build step, or external libraries are needed.

## Launch
1. Extract `NOVA-OS-8.0.0.zip`.
2. Open the `NOVA-OS-8.0.0` folder in `vscode.dev`.
3. Open `index.html` in Chrome (or use a local preview workflow).
4. Files, settings, aliases, and command history are saved in this browser's local storage, so your 7.2.x files carry over.

## What's new in 8.0.0

### Terminal / NovaShell
- **Pipes and redirects:** `ls | grep txt`, `echo hi > a.txt`, `echo yo >> a.txt`.
- **Chaining:** `a ; b`, `a && b`, `a || b`, plus `$?` for the last exit status.
- **Variables:** `export NAME=value` or `NAME=value`, then `$NAME` / `${NAME}`. Quotes, escapes, and `# comments` work.
- **Wildcards:** `ls *.txt`, `rm old-?.log`, `cp *.md backup/`.
- **Aliases** (saved in this browser): `alias ll='ls -l'`, `unalias ll`. Starter aliases: `ll`, `la`, `l`, `..`.
- **History tools:** `!!`, `!3`, `!prefix`, `history 10`, `history -c`. History survives page reloads.
- **Tab completion** for commands, aliases, and paths. **Ctrl + C** cancels `sleep`/`timer`/scripts, **Ctrl + U** clears the line, **Ctrl + L** clears the screen, **Ctrl + D** closes an extra session, **PageUp/PageDown** scroll.
- **Scripts:** `sh script.sh` (also `source`, `bash`) or `sh -c 'echo a; echo b'`.
- Every command supports `--help`, and `man`, `apropos`, `help <group>`, and `commands` make discovery easier.

### New commands (grouped as in `help`)
- **Files:** `append`, `rmdir`, `du`, `file`, `realpath`, `chmod`/`chown` (no-ops), `edit` (also `nano`/`vi`/`vim`/`code`, which open the NOVA Editor), `download`, `upload`, `backup`, `restore`. Improved: `ls -alhR`, `mkdir -p`, `rm -rf`, `cp -r`, `mv` for folders, `cd -`, `cat -n`, `head/tail -n`, `tree -L`, `find -name/-iname/-type`, `touch` multiple files.
- **Text:** `grep -invcFlr` (regex), `sort`, `uniq`, `cut`, `tr`, `sed 's/a/b/g'`, `nl`, `rev`, `tac`, `tee`, `diff`, `seq`, `base64`, `sha256`.
- **System:** `id`, `groups`, `cal` (real calendar), `date +%F`, `printenv`, `unset`, `kill`, `lscpu`, `display`, `locale`, `battery`, `netinfo` (these show only what the browser itself reports), and a new `neofetch` with a logo.
- **Customize:** `theme`, `density`, `font`, `settings`, `open`, `reset`.
- **Productivity:** `todo`, `note`, `calc` (also `expr`/`bc`), `timer`, `random`, `uuid`, `time`, `repeat`.
- **Fun:** `fortune`, `cowsay`, `banner`.
- **Packages:** `apt` (update/list/search/show/install/remove), `pacman`, `dpkg -l`. Installs are recorded only as a simulated list; nothing is downloaded.
- **Windows-style aliases:** `copy`, `move`, `del`, `md`, `rd`, `ren`, `findstr`, plus existing `dir`, `type`, `cls`, `ver`, `systeminfo`, `tasklist`, `where`.

### Desktop apps
- **Settings** now has working subdivisions (Appearance, Terminal, Editor, Storage & reset, About), also reachable from the sidebar: accent colour (presets + custom), compact/comfortable density, terminal and editor font size, editor word wrap, confirm-before-delete, backup/restore, and reset.
- **Files:** path filter with match count, folders shown, modified times, and Edit / Read / Download / Rename / Delete actions, plus Upload.
- **Editor:** unsaved-changes indicator, word/char/line counts, Ctrl + S, Revert, and Download.
- **System:** storage used, uptime, network status, and a "Run neofetch" shortcut.
- Network status in the top bar, and a layout fix so every app fills the window.

### Fixes
- `cd` no longer opens a browser popup dialog (a naming clash with the browser's `prompt` function).
- System files (`/system/version.txt`, `/etc/os-release`, …) are refreshed to the current version when loaded, so old saves no longer show stale version numbers.
- Version strings are consistent across the boot screen, shell, files, and help.

## Quick tour
```
help                       # grouped command guide
neofetch                   # system summary
mkdir -p projects/web && cd projects/web
echo "hello nova" > hi.txt
cat hi.txt | tr a-z A-Z
find /home -name '*.txt'
alias gs='ls -l /system' ; gs
todo add try NOVA 8.0.0 ; todo list
theme green
calc (2+3)*sqrt(16)
```

## Important limitations
NOVA is a browser simulation, not a real OS. Commands operate on virtual files stored in browser local storage (about 5 MB). They cannot grant administrator access, run arbitrary Chromebook commands, control crosh, install real software, or modify ChromeOS. `ping`, `curl`, and similar network tools are explained but not executed. Use `Ctrl + Alt + T` on a Chromebook to open real crosh separately. Clearing browser site data removes NOVA's saved files, so use `backup` first if you want a copy.


## NOVA OS 8.0.0 additions
- More personalization: Aurora, Midnight, Neon Grid, and Nebula backgrounds; terminal font presets; classic, minimal, and power-style prompts; show/hide clock.
- New terminal commands: `wallpaper`, `prompt`, `fontface`, `settitle`, `mkalias`, `unaliasall`, `mkcd`, `appendline`, `count`, `lower`, `upper`, `randompick`, `lorem`, `storage`, `syslog`, `reloadui`, and `help_74`.
- Settings persist in browser storage and apply immediately.
- Existing project files, terminal sessions, editor, file manager, backup/restore, and command set are retained.

Try:
```
wallpaper nebula
prompt power
fontface retro
settitle Web Development
mkalias c 'clear'
mkcd ~/projects/demo
lorem 2 > sample.txt
count sample.txt
storage
help_74
```


## NOVA OS 8.0.0 additions

### Terminal 2.0
- Drag tabs to reorder them; double-click or right-click a tab to rename it.
- Middle-click closes a tab. Right-click also offers pin/unpin, duplicate, and close.
- Toolbar actions rename, duplicate, close other tabs, and create new sessions.
- `tabs list`, `tabs new`, `tabs rename`, `tabs duplicate`, and `tabs close-others` manage sessions.
- Advanced settings control the tab limit (2–20) and close confirmation.

### Advanced customization
- Independent color controls for workspace, panels, text, muted text, terminal, terminal text, borders, and buttons.
- Random palette and reset controls; settings persist in local storage.
- Additional behavior settings for smooth scrolling, visualization line numbers, and visualization font size.

### Visualization
- New Visualization page with source selection, syntax-colored preview, line map, and file statistics.
- `visualize <file>` opens a virtual file in the visualizer.
- It analyzes text in NOVA's virtual filesystem; it does not execute or compile code.

### Modules and extensions
- New Modules page for built-in module toggles and extension status.
- `module list|enable|disable <name>` and `plugin list|enable|disable <name>`.
- This is a safe local feature manager, not an arbitrary code downloader or plugin runtime.

### Browser/ChromeOS limitations
NOVA remains a browser-based simulation. Its virtual filesystem, modules, packages, and shell commands operate inside the web app. It cannot elevate privileges, run arbitrary local programs, access the real ChromeOS filesystem, or control crosh.


## NOVA OS 8.0.0 — Major workspace release

### New in 8.0.0
- **Dashboard:** workspace health, storage meter, terminal count, network state, uptime, daily command tip, recent files, and quick-launch controls.
- **App Studio:** create persistent launch cards that route to built-in NOVA areas. These are safe shortcuts, not arbitrary executable plug-ins.
- **Quick Settings:** one-click accent presets, custom accent picker, density selector, and direct access to full settings.
- **Expanded Color Studio:** customize accent, workspace, surface, text, muted text, terminal, terminal text, borders, buttons, success, warning, error, and selection colors. Export/import themes as JSON.
- **Advanced behavior:** adjustable sidebar width, interface roundness, motion level, command-history limit, terminal output limit, startup page, editor autosave preference, and reset confirmation.
- **New shell commands:** `workspace`, `searchall`, `sessioninfo`, `pin`, `clearfilesearch`, and `apps`; `open` now recognizes dashboard, studio, and visualization.
- **Responsive layout:** dashboard and App Studio adapt to narrower Chromebook screens.

### App Studio safety
App Studio creates persistent launch cards that open existing NOVA sections. It deliberately does not execute arbitrary JavaScript or install unknown extensions. This keeps the browser-based environment safer and predictable.

### Persistence
Virtual files, folders, metadata, settings, aliases, and App Studio cards are stored in browser local storage. Export a workspace backup before clearing site data. Theme export/import is separate from workspace backup.

### Browser limitations
NOVA remains a browser simulation. It cannot elevate privileges, administer ChromeOS, run real shell commands, access crosh, or alter system settings. Some browser storage limits vary by browser and origin. For reliable local storage and future offline/PWA features, serve the folder from a local development server rather than opening `index.html` with `file://`.


### Keyboard shortcuts
- `Ctrl + Shift + P` — open/close Quick Settings.
- `Ctrl + T` — create a new terminal session (when not typing in a form field).
- `Ctrl + 1` through `Ctrl + 9` — switch to a terminal tab by position.
- `Ctrl + S` — save the current Editor file.
- `Tab` — complete terminal commands and paths.
- `↑` / `↓` — browse terminal command history.
- `Ctrl + L` — clear the active terminal display.

### Additional shell examples
```sh
workspace info
workspace backup
searchall "nova"
sessioninfo
pin on
palette list
palette set success #7ee787
apps
open dashboard
open studio
```

### Release verification
The JavaScript passes Node syntax validation, the HTML parses successfully, all static JavaScript element references resolve to an HTML ID, there are no duplicate HTML IDs, and the archive contains the complete project plus the optional PWA manifest/service worker.
