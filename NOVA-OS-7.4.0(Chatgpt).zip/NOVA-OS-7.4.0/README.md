# NOVA OS 7.4.0 — NovaShell Update

A Chromebook-friendly browser desktop simulation with a much more capable terminal.
No npm, build step, or external libraries are needed.

## Launch
1. Extract `NOVA-OS-7.4.0.zip`.
2. Open the `NOVA-OS-7.4.0` folder in `vscode.dev`.
3. Open `index.html` in Chrome (or use a local preview workflow).
4. Files, settings, aliases, and command history are saved in this browser's local storage, so your 7.2.x files carry over.

## What's new in 7.4.0

### Terminal / NovaShell
- **Pipes and redirects:** `ls | grep txt`, `echo hi > a.txt`, `echo yo >> a.txt`.
- **Chaining:** `a ; b`, `a && b`, `a || b`, plus `$?` for the last exit status.
- **Variables:** `export NAME=value` or `NAME=value`, then `$NAME` / `${NAME}`. Quotes, escapes, and `# comments` work.
- **Wildcards:** `ls *.txt`, `rm old-?.log`, `cp *.md backup/`.
- **Aliases** (saved in this browser): `alias ll='ls -l'`, `unalias ll`. Starter aliases: `ll`, `la`, `l`, `..`.
- **History tools:** `!!`, `!3`, `!prefix`, `history 10`, `history -c`. History survives page reloads.
- **Tab completion** for commands, aliases, and paths. **Ctrl + C** cancels `sleep`/`timer`/scripts, **Ctrl + U** clears the line, **Ctrl + L** clears the screen, **Ctrl + D** closes an extra session, **PageUp/PageDown** scroll.
- **Scripts:** `sh script.sh` (also `source`, `bash`) or `sh -c 'echo a; echo b'`.
- Every command supports `--help`, and `man`, `apropos`, `help <group>`, and `commands` make discovery easier.

### New commands (grouped as in `help`)
- **Files:** `append`, `rmdir`, `du`, `file`, `realpath`, `chmod`/`chown` (no-ops), `edit` (also `nano`/`vi`/`vim`/`code`, which open the NOVA Editor), `download`, `upload`, `backup`, `restore`. Improved: `ls -alhR`, `mkdir -p`, `rm -rf`, `cp -r`, `mv` for folders, `cd -`, `cat -n`, `head/tail -n`, `tree -L`, `find -name/-iname/-type`, `touch` multiple files.
- **Text:** `grep -invcFlr` (regex), `sort`, `uniq`, `cut`, `tr`, `sed 's/a/b/g'`, `nl`, `rev`, `tac`, `tee`, `diff`, `seq`, `base64`, `sha256`.
- **System:** `id`, `groups`, `cal` (real calendar), `date +%F`, `printenv`, `unset`, `kill`, `lscpu`, `display`, `locale`, `battery`, `netinfo` (these show only what the browser itself reports), and a new `neofetch` with a logo.
- **Customize:** `theme`, `density`, `font`, `settings`, `open`, `reset`.
- **Productivity:** `todo`, `note`, `calc` (also `expr`/`bc`), `timer`, `random`, `uuid`, `time`, `repeat`.
- **Fun:** `fortune`, `cowsay`, `banner`.
- **Packages:** `apt` (update/list/search/show/install/remove), `pacman`, `dpkg -l`. Installs are recorded only as a simulated list; nothing is downloaded.
- **Windows-style aliases:** `copy`, `move`, `del`, `md`, `rd`, `ren`, `findstr`, plus existing `dir`, `type`, `cls`, `ver`, `systeminfo`, `tasklist`, `where`.

### Desktop apps
- **Settings** now has working subdivisions (Appearance, Terminal, Editor, Storage & reset, About), also reachable from the sidebar: accent colour (presets + custom), compact/comfortable density, terminal and editor font size, editor word wrap, confirm-before-delete, backup/restore, and reset.
- **Files:** path filter with match count, folders shown, modified times, and Edit / Read / Download / Rename / Delete actions, plus Upload.
- **Editor:** unsaved-changes indicator, word/char/line counts, Ctrl + S, Revert, and Download.
- **System:** storage used, uptime, network status, and a "Run neofetch" shortcut.
- Network status in the top bar, and a layout fix so every app fills the window.

### Fixes
- `cd` no longer opens a browser popup dialog (a naming clash with the browser's `prompt` function).
- System files (`/system/version.txt`, `/etc/os-release`, …) are refreshed to the current version when loaded, so old saves no longer show stale version numbers.
- Version strings are consistent across the boot screen, shell, files, and help.

## Quick tour
```
help                       # grouped command guide
neofetch                   # system summary
mkdir -p projects/web && cd projects/web
echo "hello nova" > hi.txt
cat hi.txt | tr a-z A-Z
find /home -name '*.txt'
alias gs='ls -l /system' ; gs
todo add try NOVA 7.4.0 ; todo list
theme green
calc (2+3)*sqrt(16)
```

## Important limitations
NOVA is a browser simulation, not a real OS. Commands operate on virtual files stored in browser local storage (about 5 MB). They cannot grant administrator access, run arbitrary Chromebook commands, control crosh, install real software, or modify ChromeOS. `ping`, `curl`, and similar network tools are explained but not executed. Use `Ctrl + Alt + T` on a Chromebook to open real crosh separately. Clearing browser site data removes NOVA's saved files, so use `backup` first if you want a copy.


## NOVA OS 7.4.0 additions
- More personalization: Aurora, Midnight, Neon Grid, and Nebula backgrounds; terminal font presets; classic, minimal, and power-style prompts; show/hide clock.
- New terminal commands: `wallpaper`, `prompt`, `fontface`, `settitle`, `mkalias`, `unaliasall`, `mkcd`, `appendline`, `count`, `lower`, `upper`, `randompick`, `lorem`, `storage`, `syslog`, `reloadui`, and `help_74`.
- Settings persist in browser storage and apply immediately.
- Existing project files, terminal sessions, editor, file manager, backup/restore, and command set are retained.

Try:
```
wallpaper nebula
prompt power
fontface retro
settitle Web Development
mkalias c 'clear'
mkcd ~/projects/demo
lorem 2 > sample.txt
count sample.txt
storage
help_74
```
