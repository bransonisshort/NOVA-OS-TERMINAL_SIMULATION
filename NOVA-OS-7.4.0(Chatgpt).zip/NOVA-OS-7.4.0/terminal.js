/* NOVA OS 7.4.0 — NovaShell engine, virtual filesystem and desktop apps.
   Everything here is a browser simulation: it never touches ChromeOS. */
document.addEventListener("DOMContentLoaded", function () {
"use strict";

/* ---------- constants & state ---------- */
var VERSION = "7.4.0", KERNEL = "NovaCore " + VERSION + " (simulated)", SHELL = "NovaShell " + VERSION, HOME = "/home/nova";
var $ = function (id) { return document.getElementById(id); };
var KEYS = { files: "NOVA_OS_FILES", folders: "NOVA_OS_FOLDERS", meta: "NOVA_OS_META", settings: "NOVA_OS_SETTINGS", history: "NOVA_OS_HISTORY" };
var ACCENTS = { purple: "#c084fc", blue: "#60a5fa", green: "#4ade80", pink: "#f472b6", orange: "#fb923c", cyan: "#22d3ee", red: "#f87171", yellow: "#facc15" };
var BASE_PACKAGES = ["novacore", "novashell", "nova-files", "nova-editor", "nova-system-tools"];
var SYSTEM_FILES = {
  "/system/version.txt": "NOVA OS " + VERSION + " Chromebook Edition",
  "/system/kernel.txt": KERNEL,
  "/etc/hostname": "nova-chromebook",
  "/etc/os-release": "NAME=NOVA OS\nVERSION=" + VERSION + "\nEDITION=Chromebook"
};
var filesDefault = Object.assign({
  "/home/nova/welcome.txt": "Welcome to NOVA OS " + VERSION + "!\nType help to see commands. Try: neofetch, tree, todo list, theme list.",
  "/home/nova/notes.txt": "NOVA OS development notes.",
  "/home/nova/todo.txt": "",
  "/system/motd.txt": "NOVA OS online."
}, SYSTEM_FILES);
var foldersDefault = ["/", "/home", "/home/nova", "/system", "/etc", "/tmp", "/dev", "/var", "/var/log"];
function settingsDefault() {
  return { accent: ACCENTS.purple, density: "comfortable", termFont: 13, editorFont: 14, editorWrap: true, confirmDelete: true,
    wallpaper: "aurora", fontFace: "mono", promptStyle: "classic", cursorBlink: true, showClock: true,
    aliases: { ll: "ls -l", la: "ls -la", l: "ls -l", "..": "cd .." }, packages: [] };
}
var files = {}, folders = [], meta = {}, settings = settingsDefault();
var sessions = [], nextId = 1, activeId = 0, start = Date.now(), sysLog = [], storageWarned = false;
var COMMANDS = {}, GROUPS = ["Core", "Files", "Text", "System", "Customize", "Productivity", "Fun", "Packages", "ChromeOS", "Windows", "Network"];

function clone(x) { return JSON.parse(JSON.stringify(x)); }
function log(m) { sysLog.push(new Date().toLocaleTimeString() + " " + m); if (sysLog.length > 200) sysLog.shift(); }

/* ---------- persistence ---------- */
function readJSON(key) { try { return JSON.parse(localStorage.getItem(key)); } catch (e) { return null; } }
function load() {
  var f = readJSON(KEYS.files), fo = readJSON(KEYS.folders), m = readJSON(KEYS.meta), st = readJSON(KEYS.settings);
  files = (f && typeof f === "object" && !Array.isArray(f)) ? f : clone(filesDefault);
  folders = Array.isArray(fo) ? fo : foldersDefault.slice();
  foldersDefault.forEach(function (d) { if (folders.indexOf(d) < 0) folders.push(d); });
  Object.keys(SYSTEM_FILES).forEach(function (p) { files[p] = SYSTEM_FILES[p]; });   // system files always match this version
  Object.keys(files).forEach(function (p) { if (typeof files[p] !== "string") files[p] = String(files[p]); });
  meta = (m && typeof m === "object" && !Array.isArray(m)) ? m : {};
  var now = Date.now();
  Object.keys(files).concat(folders).forEach(function (p) { if (typeof meta[p] !== "number") meta[p] = now; });
  settings = Object.assign(settingsDefault(), (st && typeof st === "object") ? st : {});
  if (!settings.aliases || typeof settings.aliases !== "object") settings.aliases = settingsDefault().aliases;
  if (!Array.isArray(settings.packages)) settings.packages = [];
}
function persist() {
  try {
    localStorage.setItem(KEYS.files, JSON.stringify(files));
    localStorage.setItem(KEYS.folders, JSON.stringify(folders));
    localStorage.setItem(KEYS.meta, JSON.stringify(meta));
    return true;
  } catch (e) {
    if (!storageWarned) { storageWarned = true; print("Browser storage unavailable or full — changes may not be saved.", "warning"); }
    return false;
  }
}
function saveSettings() { try { localStorage.setItem(KEYS.settings, JSON.stringify(settings)); } catch (e) {} }
function pushGlobalHistory(line) {
  try { var all = readJSON(KEYS.history) || []; all.push(line); localStorage.setItem(KEYS.history, JSON.stringify(all.slice(-200))); } catch (e) {}
}

/* ---------- paths & filesystem helpers ---------- */
function path(p, base) {
  p = p || "~";
  if (p === "~") p = HOME; else if (p.indexOf("~/") === 0) p = HOME + p.slice(1);
  var parts = (p[0] === "/" ? p : (base || cwd()) + "/" + p).split("/"), out = [];
  parts.forEach(function (x) { if (!x || x === ".") return; if (x === "..") out.pop(); else out.push(x); });
  return "/" + out.join("/");
}
function parent(p) { if (p === "/") return "/"; var i = p.lastIndexOf("/"); return i <= 0 ? "/" : p.slice(0, i); }
function base(p) { return p === "/" ? "/" : p.slice(p.lastIndexOf("/") + 1); }
function isFile(p) { return Object.prototype.hasOwnProperty.call(files, p); }
function isDir(p) { return folders.indexOf(p) >= 0; }
function exists(p) { return isFile(p) || isDir(p); }
function under(p, dir) { return dir === "/" ? p !== "/" : p.indexOf(dir + "/") === 0; }
function children(dir) {
  var a = [];
  folders.forEach(function (p) { if (p !== dir && parent(p) === dir) a.push({ p: p, name: base(p), d: true }); });
  Object.keys(files).forEach(function (p) { if (parent(p) === dir) a.push({ p: p, name: base(p), d: false }); });
  return a.sort(function (x, y) { return x.name.localeCompare(y.name); });
}
function descendants(dir) { return Object.keys(files).concat(folders).filter(function (p) { return under(p, dir); }).sort(); }
function stamp(p) { meta[p] = Date.now(); }
function fsWrite(p, text, evt) { var isNew = !isFile(p); files[p] = text; stamp(p); persist(); eventFS(evt || (isNew ? "create" : "write"), p); }
function fsMkdir(p) { folders.push(p); stamp(p); }
function fsDelete(p) { delete files[p]; delete meta[p]; }
function fsRmdir(p) { folders = folders.filter(function (f) { return f !== p; }); delete meta[p]; }
function bytes(text) { try { return new Blob([text]).size; } catch (e) { return text.length; } }
function totalBytes() { return Object.keys(files).reduce(function (n, p) { return n + bytes(files[p]) + p.length; }, 0); }
function humanSize(n) { if (n < 1024) return n + " B"; if (n < 1048576) return (n / 1024).toFixed(1) + " KB"; return (n / 1048576).toFixed(2) + " MB"; }
function fixCwds() { sessions.forEach(function (s) { if (!isDir(s.cwd)) s.cwd = HOME; }); }
function eventFS(type, p) { document.dispatchEvent(new CustomEvent("nova-filesystem-change", { detail: { type: type, path: p } })); }
function globToRe(g, ci) { return new RegExp("^" + g.replace(/[.+^${}()|\[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".") + "$", ci ? "i" : ""); }
function glob(pat, s) {
  if (!/[*?]/.test(pat)) return [pat];
  var i = pat.lastIndexOf("/"), dirPart = i >= 0 ? pat.slice(0, i + 1) : "", basePat = pat.slice(i + 1);
  if (/[*?]/.test(dirPart)) return [pat];
  var dir = path(dirPart || ".", s.cwd);
  if (!isDir(dir)) return [pat];
  var re = globToRe(basePat), m = children(dir).filter(function (c) { return re.test(c.name) && (c.name[0] !== "." || basePat[0] === "."); }).map(function (c) { return dirPart + c.name; });
  return m.length ? m : [pat];
}
function fmtDate(t) {
  var d = new Date(t), mo = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][d.getMonth()];
  return mo + " " + String(d.getDate()).padStart(2, " ") + " " + String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
}

/* ---------- sessions & output ---------- */
function session() { return sessions.find(function (s) { return s.id === activeId; }) || sessions[0]; }
function cwd() { return session() ? session().cwd : HOME; }
function screen(s) { return $("screen-" + s.id); }
var MAX_LINES = 1500;
function print(t, k, s) {
  s = s || session(); if (!s) return;
  var el = screen(s); if (!el) return;
  var d = document.createElement("div"); d.className = "line " + (k || ""); d.textContent = String(t === undefined ? "" : t);
  el.appendChild(d); el.scrollTop = el.scrollHeight;
  s.output.push({ text: d.textContent, kind: k || "" });
  if (s.output.length > MAX_LINES) { s.output.shift(); if (el.firstChild) el.removeChild(el.firstChild); }
}
function promptText(s) {
  var loc = s.cwd === HOME ? "~" : s.cwd, style = settings.promptStyle || "classic";
  if (style === "minimal") return loc + " >";
  if (style === "power") return "┌─ nova " + loc + "\\n└─❯";
  return "nova@nova-chromebook:" + loc + "$";
}
function updatePrompt() { var s = session(); if (s) $("prompt").textContent = promptText(s); }
function newSession(name) {
  var id = nextId++;
  return { id: id, name: name || ("Terminal " + id), cwd: HOME, oldcwd: HOME, history: [], hi: 0, output: [], env: {}, status: 0, running: false, cancel: false };
}
function drawTabs() {
  $("terminal-tabs").innerHTML = ""; $("terminal-screens").innerHTML = "";
  sessions.forEach(function (s) {
    var b = document.createElement("button"); b.className = "terminal-tab" + (s.id === activeId ? " active" : ""); b.appendChild(document.createTextNode(s.name));
    if (sessions.length > 1) { var x = document.createElement("span"); x.className = "close-tab"; x.textContent = "×"; x.title = "Close session"; x.onclick = function (e) { e.stopPropagation(); closeSession(s.id); }; b.appendChild(x); }
    b.onclick = function () { switchSession(s.id); }; $("terminal-tabs").appendChild(b);
    var sc = document.createElement("div"); sc.id = "screen-" + s.id; sc.className = "terminal-screen" + (s.id === activeId ? "" : " hidden"); $("terminal-screens").appendChild(sc);
    s.output.forEach(function (o) { var d = document.createElement("div"); d.className = "line " + o.kind; d.textContent = o.text; sc.appendChild(d); });
    sc.scrollTop = sc.scrollHeight;
  });
  var add = document.createElement("button"); add.className = "new-tab"; add.textContent = "+"; add.title = "New terminal"; add.onclick = createSession; $("terminal-tabs").appendChild(add);
  updatePrompt(); updateSystem();
}
function switchSession(id) { activeId = id; drawTabs(); $("command-input").focus(); }
function createSession() {
  if (sessions.length >= 8) { print("Maximum of 8 terminal sessions reached.", "warning"); return; }
  var s = newSession(); sessions.push(s); activeId = s.id; drawTabs();
  print("NOVA OS " + VERSION + " — new independent terminal session", "success");
  print("Working directory and history are separate; files are shared.", "info");
  $("command-input").focus();
}
function closeSession(id) {
  if (sessions.length === 1) { print("At least one terminal session must remain.", "warning"); return; }
  sessions = sessions.filter(function (s) { return s.id !== id; });
  if (activeId === id) activeId = sessions[0].id; drawTabs();
}

/* ---------- settings application ---------- */
function applySettings() {
  var r = document.documentElement.style;
  r.setProperty("--accent", settings.accent);
  r.setProperty("--term-font", settings.termFont + "px");
  r.setProperty("--editor-font", settings.editorFont + "px");
  document.body.setAttribute("data-wallpaper", settings.wallpaper || "aurora");
  document.body.setAttribute("data-font-face", settings.fontFace || "mono");
  document.body.setAttribute("data-prompt-style", settings.promptStyle || "classic");
  document.body.classList.toggle("no-cursor-blink", settings.cursorBlink === false);
  $("clock").classList.toggle("hidden", settings.showClock === false);
  document.body.setAttribute("data-density", settings.density);
  $("editor-content").classList.toggle("nowrap", !settings.editorWrap);
  $("editor-content").setAttribute("wrap", settings.editorWrap ? "soft" : "off");
  renderSettings();
}
function setSetting(key, value) { settings[key] = value; saveSettings(); applySettings(); }
function colorOk(c) { return /^#[0-9a-f]{6}$/i.test(c); }

/* ---------- tokenizer / parser ---------- */
function getEnv(s) {
  var e = { USER: "nova", HOME: HOME, SHELL: "NovaShell", HOSTNAME: "nova-chromebook", PATH: "/usr/bin:/bin", PWD: s.cwd, OLDPWD: s.oldcwd,
    TERM: "nova-term", LANG: navigator.language || "en-US", NOVA_VERSION: VERSION };
  Object.keys(s.env).forEach(function (k) { e[k] = s.env[k]; });
  return e;
}
function expandVar(line, i, s) {
  var n = line[i + 1], m;
  if (n === "?") return { v: String(s.status), i: i + 2 };
  if (n === "{") { var end = line.indexOf("}", i); if (end > 0) { var nm = line.slice(i + 2, end), ev = getEnv(s); return { v: ev[nm] !== undefined ? ev[nm] : "", i: end + 1 }; } }
  m = /^[A-Za-z_]\w*/.exec(line.slice(i + 1));
  if (m) { var e2 = getEnv(s); return { v: e2[m[0]] !== undefined ? e2[m[0]] : "", i: i + 1 + m[0].length }; }
  return { v: "$", i: i + 1 };
}
function tokenize(line, s) {
  var tokens = [], cur = "", has = false, q = "", quoted = false, i = 0, c, r;
  function push() { if (has) tokens.push({ t: "w", v: cur, quoted: quoted }); cur = ""; has = false; quoted = false; }
  while (i < line.length) {
    c = line[i];
    if (q) {
      if (c === q) { q = ""; i++; continue; }
      if (q === '"' && c === "\\" && i + 1 < line.length && '"\\$`'.indexOf(line[i + 1]) >= 0) { cur += line[i + 1]; i += 2; continue; }
      if (q === '"' && c === "$") { r = expandVar(line, i, s); cur += r.v; i = r.i; continue; }
      cur += c; i++; continue;
    }
    if (c === "'" || c === '"') { q = c; has = true; quoted = true; i++; continue; }
    if (c === "\\") { if (i + 1 < line.length) { cur += line[i + 1]; has = true; quoted = true; i += 2; } else i++; continue; }
    if (c === "$") { r = expandVar(line, i, s); if (r.v !== "") { cur += r.v; has = true; } i = r.i; continue; }
    if (c === "#" && !has && (i + 1 >= line.length || /\s/.test(line[i + 1]))) break;
    if (/\s/.test(c)) { push(); i++; continue; }
    if (c === "|") { push(); tokens.push({ t: "op", v: "|" }); i++; continue; }
    if (c === ">") { push(); if (line[i + 1] === ">") { tokens.push({ t: "op", v: ">>" }); i += 2; } else { tokens.push({ t: "op", v: ">" }); i++; } continue; }
    if (c === "~" && !has && (i + 1 >= line.length || /[\s\/|;&>]/.test(line[i + 1]))) { cur += HOME; has = true; i++; continue; }
    cur += c; has = true; i++;
  }
  if (q) return { error: "unterminated quote (" + q + ")" };
  push();
  return { tokens: tokens };
}
function parsePipe(tokens) {
  var pipe = [], cmd = { argv: [], redir: null }, pend = null, err = null;
  tokens.forEach(function (tk) {
    if (err) return;
    if (tk.t === "w") { if (pend) { pend.target = tk.v; cmd.redir = pend; pend = null; } else cmd.argv.push(tk); }
    else if (tk.v === ">" || tk.v === ">>") { if (pend) err = "syntax error near '" + tk.v + "'"; pend = { op: tk.v }; }
    else { if (!cmd.argv.length || pend) err = "syntax error near '|'"; pipe.push(cmd); cmd = { argv: [], redir: null }; }
  });
  if (err) return { error: err };
  if (pend) return { error: "syntax error: missing redirect target" };
  if (!cmd.argv.length) return pipe.length ? { error: "syntax error: unexpected end of line" } : { pipe: [] };
  pipe.push(cmd);
  return { pipe: pipe };
}
// Split on ; && || outside quotes, so variables are expanded only when each part actually runs.
function splitSeq(line) {
  var out = [], cur = "", q = "", i = 0, c, ws = true;
  while (i < line.length) {
    c = line[i];
    if (q) { cur += c; if (c === "\\" && q === '"' && i + 1 < line.length) { cur += line[++i]; } else if (c === q) q = ""; i++; continue; }
    if (c === "'" || c === '"') { q = c; cur += c; i++; ws = false; continue; }
    if (c === "\\") { cur += c + (line[i + 1] || ""); i += 2; ws = false; continue; }
    if (c === "#" && ws && (i + 1 >= line.length || /\s/.test(line[i + 1]))) break;
    if (c === ";") { out.push({ text: cur, op: ";" }); cur = ""; i++; ws = true; continue; }
    if (c === "&" && line[i + 1] === "&") { out.push({ text: cur, op: "&&" }); cur = ""; i += 2; ws = true; continue; }
    if (c === "|" && line[i + 1] === "|") { out.push({ text: cur, op: "||" }); cur = ""; i += 2; ws = true; continue; }
    ws = /\s/.test(c) || c === "|" || c === ">"; cur += c; i++;
  }
  if (q) return { error: "unterminated quote (" + q + ")" };
  out.push({ text: cur, op: null });
  return { segs: out };
}
function expandAliases(argv, s) {
  var seen = {};
  while (argv.length && !argv[0].quoted && Object.prototype.hasOwnProperty.call(settings.aliases, argv[0].v) && !seen[argv[0].v]) {
    seen[argv[0].v] = true;
    var t = tokenize(settings.aliases[argv[0].v], s);
    if (t.error) break;
    var words = t.tokens.filter(function (x) { return x.t === "w"; });
    argv = words.concat(argv.slice(1));
  }
  return argv;
}

/* ---------- command registry & execution ---------- */
function def(name, group, usage, desc, fn, example) { COMMANDS[name] = { name: name, g: group, u: usage, d: desc, f: fn, x: example || "" }; }
function defAlias(name, target, group) { var t = COMMANDS[target]; COMMANDS[name] = { name: name, g: group || t.g, u: t.u.replace(target, name), d: t.d + " (alias of " + target + ")", f: t.f, x: "" }; }
function commandNames() { return Object.keys(COMMANDS).sort(); }

function parseFlags(args, valLetters) {
  var r = { f: {}, v: {}, o: [] }, end = false, i, j, a, ch, val, eq;
  for (i = 0; i < args.length; i++) {
    a = args[i];
    if (end || a === "-" || a[0] !== "-") { r.o.push(a); continue; }
    if (a === "--") { end = true; continue; }
    if (/^-\d+$/.test(a)) { r.v.n = a.slice(1); r.f.n = true; continue; }
    if (a.indexOf("--") === 0) { eq = a.indexOf("="); if (eq > 0) { r.v[a.slice(2, eq)] = a.slice(eq + 1); r.f[a.slice(2, eq)] = true; } else r.f[a.slice(2)] = true; continue; }
    for (j = 1; j < a.length; j++) {
      ch = a[j]; r.f[ch] = true;
      if (valLetters && valLetters.indexOf(ch) >= 0) { val = a.slice(j + 1); if (!val) val = args[++i]; r.v[ch] = val; break; }
    }
  }
  return r;
}
function toLines(t) { if (t === "") return []; var l = t.split("\n"); if (l.length > 1 && l[l.length - 1] === "") l.pop(); return l; }
function readSources(c, operands, name) {
  if (!operands.length) { if (c.stdin !== null) return [{ name: "-", text: c.stdin }]; c.err(name + ": missing file operand (or pipe input into it)"); return null; }
  var out = [];
  operands.forEach(function (op) {
    var p = path(op, c.s.cwd);
    if (isFile(p)) out.push({ name: op, text: files[p], path: p });
    else if (isDir(p)) c.err(name + ": " + op + ": Is a directory");
    else c.err(name + ": " + op + ": No such file or directory");
  });
  return out;
}
function unesc(t) { return t.replace(/\\(n|t|r|\\)/g, function (m, x) { return x === "n" ? "\n" : x === "t" ? "\t" : x === "r" ? "\r" : "\\"; }); }

async function execCommand(cmd, s, stdin, tty) {
  var argv = expandAliases(cmd.argv, s), words = [];
  argv.forEach(function (a, i) { if (i > 0 && !a.quoted && /[*?]/.test(a.v)) glob(a.v, s).forEach(function (x) { words.push(x); }); else words.push(a.v); });
  if (!words.length) return { chunks: [], code: 0 };
  var chunks = [], name = words[0], am = /^([A-Za-z_]\w*)=(.*)$/.exec(name);
  if (am && !argv[0].quoted) { s.env[am[1]] = am[2]; return { chunks: [], code: 0 }; }
  var ctx = {
    s: s, name: name.toLowerCase(), args: words.slice(1), stdin: stdin, tty: tty, chunks: chunks, code: 0,
    write: function (t, k) { chunks.push({ text: String(t), kind: k || "" }); },
    err: function (t) { print(t, "error", s); ctx.code = 1; return 1; },
    exec: async function (av) {
      var r = await execCommand({ argv: av.map(function (v) { return { v: v, quoted: true }; }), redir: null }, s, ctx.stdin, ctx.tty);
      r.chunks.forEach(function (ch) { chunks.push(ch); }); return r.code;
    }
  };
  var d = COMMANDS[ctx.name];
  if (!d) { ctx.err(name + ": command not found. Type help."); return { chunks: chunks, code: 127 }; }
  if (words.length === 2 && words[1] === "--help") { ctx.write("Usage: " + d.u + "\n" + d.d, "info"); return { chunks: chunks, code: 0 }; }
  try { var r = await d.f(ctx); if (typeof r === "number") ctx.code = r; }
  catch (e) { ctx.err(name + ": " + (e && e.message ? e.message : e)); ctx.code = 1; }
  return { chunks: chunks, code: ctx.code };
}
async function execPipeline(pipe, s) {
  var input = null, code = 0;
  for (var i = 0; i < pipe.length; i++) {
    var cmd = pipe[i], last = i === pipe.length - 1;
    var res = await execCommand(cmd, s, input, last && !cmd.redir);
    code = res.code;
    var text = res.chunks.map(function (c) { return c.text; }).join("\n");
    if (cmd.redir) {
      var tp = path(cmd.redir.target, s.cwd);
      if (isDir(tp)) { print("nova: " + cmd.redir.target + ": Is a directory", "error", s); code = 1; }
      else if (!isDir(parent(tp))) { print("nova: " + cmd.redir.target + ": No such directory", "error", s); code = 1; }
      else fsWrite(tp, (cmd.redir.op === ">>" && isFile(tp) && files[tp] !== "") ? files[tp] + "\n" + text : text);
      input = "";
    } else if (!last) input = text;
    else res.chunks.forEach(function (c) { print(c.text, c.kind, s); });
    if (s.cancel) break;
  }
  return code;
}
async function execLine(line, s) {
  var sp = splitSeq(line);
  if (sp.error) { print("nova: " + sp.error, "error", s); s.status = 2; return 2; }
  var prev = null;
  for (var i = 0; i < sp.segs.length; i++) {
    var seg = sp.segs[i], skip = (prev === "&&" && s.status !== 0) || (prev === "||" && s.status === 0);
    prev = seg.op;
    if (skip || !seg.text.trim()) continue;
    var t = tokenize(seg.text, s);
    if (t.error) { print("nova: " + t.error, "error", s); s.status = 2; continue; }
    var p = parsePipe(t.tokens);
    if (p.error) { print("nova: " + p.error, "error", s); s.status = 2; continue; }
    if (!p.pipe.length) continue;
    s.status = await execPipeline(p.pipe, s);
    if (s.cancel) break;
  }
  return s.status;
}
async function runLine(raw, s) {
  var line = raw.trim(); if (!line) return;
  if (line[0] === "!" && line.length > 1 && !/\s/.test(line[1])) {
    var h = s.history, found;
    if (line === "!!") found = h[h.length - 1];
    else if (/^!\d+$/.test(line)) found = h[parseInt(line.slice(1), 10) - 1];
    else { var pre = line.slice(1); for (var k = h.length - 1; k >= 0; k--) if (h[k].indexOf(pre) === 0) { found = h[k]; break; } }
    if (!found) { print("nova: " + line + ": event not found", "error", s); return; }
    line = found;
  }
  print(promptText(s) + " " + line, "command", s);
  s.history.push(line); if (s.history.length > 500) s.history.shift(); s.hi = s.history.length; pushGlobalHistory(line);
  s.running = true; s.cancel = false;
  try { await execLine(line, s); }
  catch (e) { print("Terminal error: " + (e && e.message ? e.message : e), "error", s); }
  s.running = false; s.cancel = false;
  if (s.id === activeId) updatePrompt();
}
function sleepMs(ms, s) {
  return new Promise(function (res) { var t0 = Date.now(), iv = setInterval(function () { if (s.cancel || Date.now() - t0 >= ms) { clearInterval(iv); res(); } }, 50); });
}

/* ---------- shared command helpers ---------- */
function tfmt(d, f) {
  var D = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"], M = ["January","February","March","April","May","June","July","August","September","October","November","December"];
  var z = function (n, w) { return String(n).padStart(w || 2, "0"); };
  return f.replace(/%([a-zA-Z%])/g, function (m, x) {
    switch (x) {
      case "Y": return d.getFullYear(); case "y": return z(d.getFullYear() % 100); case "m": return z(d.getMonth() + 1); case "d": return z(d.getDate());
      case "H": return z(d.getHours()); case "M": return z(d.getMinutes()); case "S": return z(d.getSeconds()); case "I": return z(d.getHours() % 12 || 12);
      case "p": return d.getHours() < 12 ? "AM" : "PM"; case "A": return D[d.getDay()]; case "a": return D[d.getDay()].slice(0, 3);
      case "B": return M[d.getMonth()]; case "b": return M[d.getMonth()].slice(0, 3); case "F": return d.getFullYear() + "-" + z(d.getMonth() + 1) + "-" + z(d.getDate());
      case "T": return z(d.getHours()) + ":" + z(d.getMinutes()) + ":" + z(d.getSeconds()); case "s": return Math.floor(d.getTime() / 1000);
      case "j": return z(Math.floor((d - new Date(d.getFullYear(), 0, 0)) / 864e5), 3); case "%": return "%"; default: return m;
    }
  });
}
function calcExpr(src) {
  var toks = src.match(/\d*\.?\d+(?:e[+-]?\d+)?|[a-z_]+|\*\*|[-+*\/%^(),]/gi) || [], pos = 0;
  var fns = { sqrt: Math.sqrt, sin: Math.sin, cos: Math.cos, tan: Math.tan, log: Math.log10, ln: Math.log, abs: Math.abs, round: Math.round, floor: Math.floor, ceil: Math.ceil, min: Math.min, max: Math.max, exp: Math.exp };
  var consts = { pi: Math.PI, e: Math.E };
  function peek() { return toks[pos]; }
  function expr() { var v = term(); while (peek() === "+" || peek() === "-") { var o = toks[pos++], r = term(); v = o === "+" ? v + r : v - r; } return v; }
  function term() { var v = pw(); while (peek() === "*" || peek() === "/" || peek() === "%") { var o = toks[pos++], r = pw(); if ((o === "/" || o === "%") && r === 0) throw new Error("division by zero"); v = o === "*" ? v * r : o === "/" ? v / r : v % r; } return v; }
  function pw() { var b = unary(); if (peek() === "^" || peek() === "**") { pos++; return Math.pow(b, pw()); } return b; }
  function unary() { if (peek() === "-") { pos++; return -unary(); } if (peek() === "+") { pos++; return unary(); } return prim(); }
  function prim() {
    var t = toks[pos++];
    if (t === undefined) throw new Error("unexpected end of expression");
    if (t === "(") { var v = expr(); if (toks[pos++] !== ")") throw new Error("missing )"); return v; }
    if (/^[\d.]/.test(t)) return parseFloat(t);
    var lt = t.toLowerCase();
    if (consts[lt] !== undefined) return consts[lt];
    if (fns[lt]) { if (toks[pos++] !== "(") throw new Error("expected ( after " + t); var a = []; if (peek() !== ")") { a.push(expr()); while (peek() === ",") { pos++; a.push(expr()); } } if (toks[pos++] !== ")") throw new Error("missing )"); return fns[lt].apply(null, a); }
    throw new Error("unknown token: " + t);
  }
  if (!toks.length) throw new Error("empty expression");
  var res = expr(); if (pos < toks.length) throw new Error("unexpected " + toks[pos]);
  return res;
}
function diffLines(a, b) {
  var n = a.length, m = b.length, dp = [], i, j, out = [];
  for (i = 0; i <= n; i++) dp.push(new Array(m + 1).fill(0));
  for (i = n - 1; i >= 0; i--) for (j = m - 1; j >= 0; j--) dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
  i = 0; j = 0;
  while (i < n && j < m) { if (a[i] === b[j]) { i++; j++; } else if (dp[i + 1][j] >= dp[i][j + 1]) out.push("< " + a[i++]); else out.push("> " + b[j++]); }
  while (i < n) out.push("< " + a[i++]); while (j < m) out.push("> " + b[j++]);
  return out;
}
function copyTree(src, dst, move) {
  if (isFile(src)) { files[dst] = files[src]; meta[dst] = Date.now(); if (move) fsDelete(src); return; }
  var all = [src].concat(descendants(src));
  all.forEach(function (p) { var np = dst + p.slice(src.length); if (isDir(p)) { if (!isDir(np)) folders.push(np); meta[np] = Date.now(); } else { files[np] = files[p]; meta[np] = Date.now(); } });
  if (move) all.slice().reverse().forEach(function (p) { if (isDir(p)) fsRmdir(p); else fsDelete(p); });
}
function expandSet(s) {
  s = s.replace(/\[:upper:\]/g, "A-Z").replace(/\[:lower:\]/g, "a-z").replace(/\[:digit:\]/g, "0-9").replace(/\[:space:\]/g, " \t\n");
  var out = "", i = 0;
  while (i < s.length) { if (s[i + 1] === "-" && i + 2 < s.length) { for (var k = s.charCodeAt(i); k <= s.charCodeAt(i + 2); k++) out += String.fromCharCode(k); i += 3; } else out += s[i++]; }
  return out;
}
function rangeSpec(spec, max) {
  var idx = [];
  String(spec || "").split(",").forEach(function (part) {
    var m = /^(\d*)-(\d*)$/.exec(part);
    if (m) { var a = m[1] ? +m[1] : 1, b = m[2] ? +m[2] : max; for (var i = a; i <= b; i++) idx.push(i); }
    else if (/^\d+$/.test(part)) idx.push(+part);
  });
  return idx;
}
function downloadText(name, text, mime) {
  var a = document.createElement("a"), url = URL.createObjectURL(new Blob([text], { type: mime || "text/plain" }));
  a.href = url; a.download = name; document.body.appendChild(a); a.click(); document.body.removeChild(a); setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
}
function pickFiles(multiple, accept, cb) {
  var inp = document.createElement("input"); inp.type = "file"; inp.multiple = !!multiple; if (accept) inp.accept = accept;
  inp.onchange = function () { cb(Array.prototype.slice.call(inp.files)); }; inp.click();
}
function readFileText(file) { return new Promise(function (res, rej) { var r = new FileReader(); r.onload = function () { res(String(r.result)); }; r.onerror = function () { rej(new Error("could not read " + file.name)); }; r.readAsText(file); }); }

/* ======================= COMMANDS: Core ======================= */
def("help", "Core", "help [command|group]", "Show the command guide, a command group, or one command.", function (c) {
  var a = (c.args[0] || "").toLowerCase();
  if (a && COMMANDS[a]) { c.write(manText(a), "info"); return; }
  var grp = GROUPS.filter(function (g) { return g.toLowerCase() === a; })[0];
  if (a && !grp) return c.err("help: no command or group named '" + a + "'. Groups: " + GROUPS.join(", ").toLowerCase());
  var out = ["NOVA OS " + VERSION + " — COMMAND GUIDE", ""];
  (grp ? [grp] : GROUPS).forEach(function (g) {
    var names = commandNames().filter(function (n) { return COMMANDS[n].g === g; });
    if (!names.length) return;
    if (grp) { out.push(g + ":"); names.forEach(function (n) { out.push("  " + n.padEnd(12) + COMMANDS[n].d); }); }
    else out.push(g + ": " + names.join(", "));
  });
  if (!grp) out.push("", "Shell features: pipes (a | b), redirects (> >>), chaining (; && ||), $VARS, globs (*.txt), aliases, !! history, Tab completion.",
    "Keys: ↑/↓ history · Tab complete · Ctrl+C cancel · Ctrl+L clear · Ctrl+U clear line · PageUp/PageDown scroll.",
    "Tips: help <group> lists a group · man <command> shows details · apropos <word> searches · commands lists all.",
    "These are simulations only, not a real OS shell. Paths are virtual and begin at /home/nova.");
  c.write(out.join("\n"), "info");
});
function manText(n) {
  var d = COMMANDS[n]; if (!d) return "No manual entry for " + n + "; type help.";
  return "NAME\n  " + n + " — " + d.d + "\nGROUP\n  " + d.g + "\nUSAGE\n  " + d.u + (d.x ? "\nEXAMPLE\n  " + d.x : "");
}
def("man", "Core", "man <command>", "Show a manual page for a command.", function (c) {
  var n = (c.args[0] || "").toLowerCase(); if (!n) return c.err("usage: man <command>");
  if (!COMMANDS[n]) return c.err("No manual entry for " + n + "; type help.");
  c.write(manText(n), "info");
}, "man grep");
def("apropos", "Core", "apropos <word>", "Search command names and descriptions.", function (c) {
  var q = c.args.join(" ").toLowerCase(); if (!q) return c.err("usage: apropos <word>");
  var m = commandNames().filter(function (n) { return n.indexOf(q) >= 0 || COMMANDS[n].d.toLowerCase().indexOf(q) >= 0; });
  if (!m.length) { c.write("Nothing appropriate."); return 1; }
  c.write(m.map(function (n) { return n.padEnd(12) + COMMANDS[n].d; }).join("\n"));
}, "apropos file");
def("commands", "Core", "commands", "List every available command name.", function (c) { var n = commandNames(); c.write(n.length + " commands:\n" + n.join(" "), "info"); });
def("clear", "Core", "clear", "Clear the active terminal display (Ctrl+L).", function (c) { c.s.output = []; var e = screen(c.s); if (e) e.innerHTML = ""; });
defAlias("cls", "clear", "Windows");
def("history", "Core", "history [N | -c]", "Show command history for this session; -c clears it.", function (c) {
  var f = parseFlags(c.args);
  if (f.f.c) { c.s.history = []; c.s.hi = 0; try { localStorage.removeItem(KEYS.history); } catch (e) {} c.write("History cleared.", "success"); return; }
  var h = c.s.history, n = parseInt(f.o[0], 10), from = n > 0 ? Math.max(0, h.length - n) : 0;
  c.write(h.slice(from).map(function (x, i) { return String(from + i + 1).padStart(4) + "  " + x; }).join("\n") || "(empty)");
}, "history 10");
def("exit", "Core", "exit", "Close this terminal session.", function (c) { if (sessions.length > 1) closeSession(c.s.id); else c.write("Open another session before closing the last one.", "warning"); });
def("about", "Core", "about", "About NOVA OS.", function (c) { c.write("NOVA OS " + VERSION + " is a browser-based OS simulator. Commands are simulated; no real OS settings change.", "info"); });
def("version", "Core", "version", "Print the NOVA OS, kernel and shell versions.", function (c) { c.write("NOVA OS " + VERSION + "\n" + KERNEL + "\n" + SHELL); });
def("banner", "Core", "banner", "Show the NOVA version banner.", function (c) {
  c.write("  _   _  _____     __  ___    ___  ___\n | \\ | |/ _ \\ \\   / / / _ \\  / _ \\/ __|\n |  \\| | | | \\ \\ / / | | | || | | \\__ \\\n | |\\  | |_| |\\ V /  | |_| || |_| |___) |\n |_| \\_|\\___/  \\_/    \\___/  \\___/|____/\n NOVA OS " + VERSION + " — Chromebook Edition", "success");
});
def("echo", "Core", "echo [-n] [-e] [text...]", "Print text (-e interprets \\n and \\t).", function (c) {
  var a = c.args.slice(), esc = false;
  while (a.length && /^-[neE]+$/.test(a[0])) { if (a[0].indexOf("e") > 0) esc = true; a.shift(); }
  var t = a.join(" "); c.write(esc ? unesc(t) : t);
}, "echo hello > hi.txt");
def("printf", "Core", "printf <format> [args...]", "Format text with %s %d %f %x and \\n \\t.", function (c) {
  if (!c.args.length) return c.err("usage: printf <format> [args...]");
  var fmt = unesc(c.args[0]), args = c.args.slice(1), out = "", guard = 0;
  do {
    out += fmt.replace(/%([sdfx%])/g, function (m, x) {
      if (x === "%") return "%"; var v = args.shift(); if (v === undefined) return "";
      return x === "d" ? String(parseInt(v, 10) || 0) : x === "f" ? String(parseFloat(v) || 0) : x === "x" ? (parseInt(v, 10) || 0).toString(16) : v;
    });
  } while (args.length && /%[sdfx]/.test(fmt) && ++guard < 100);
  c.write(out.replace(/\n$/, ""));
}, 'printf "%s is %d\\n" age 7');
def("sleep", "Core", "sleep <seconds>", "Wait (Ctrl+C cancels). Max 60 seconds.", async function (c) {
  var n = parseFloat(c.args[0]); if (!(n >= 0)) return c.err("usage: sleep <seconds>");
  await sleepMs(Math.min(n, 60) * 1000, c.s);
}, "sleep 2 && echo done");
def("true", "Core", "true", "Do nothing, successfully.", function () { return 0; });
def("false", "Core", "false", "Do nothing, unsuccessfully.", function () { return 1; });
def("time", "Core", "time <command...>", "Run a command and report how long it took.", async function (c) {
  if (!c.args.length) return c.err("usage: time <command...>");
  var t0 = performance.now(), code = await c.exec(c.args); c.write("real " + ((performance.now() - t0) / 1000).toFixed(3) + "s", "info"); return code;
}, "time ls -R");
def("repeat", "Core", "repeat <N> <command...>", "Run a command N times (max 20).", async function (c) {
  var n = parseInt(c.args[0], 10); if (!(n > 0) || c.args.length < 2) return c.err("usage: repeat <N> <command...>");
  for (var i = 0; i < Math.min(n, 20) && !c.s.cancel; i++) await c.exec(c.args.slice(1));
}, "repeat 3 echo hi");
def("sudo", "Core", "sudo <command...>", "Run a command (administrator privileges are simulated only).", async function (c) {
  c.write("Administrator privileges are simulated only.", "warning");
  if (c.args.length) return await c.exec(c.args);
});
def("alias", "Core", "alias [name='command']", "List or create command aliases (saved in this browser).", function (c) {
  if (!c.args.length) { var k = Object.keys(settings.aliases).sort(); c.write(k.map(function (n) { return "alias " + n + "='" + settings.aliases[n] + "'"; }).join("\n") || "(no aliases)"); return; }
  var tail = c.args.join(" "), m = /^([^\s=]+)=(.*)$/.exec(tail);
  if (!m) { var v = settings.aliases[tail]; if (v === undefined) return c.err("alias: " + tail + ": not found"); c.write("alias " + tail + "='" + v + "'"); return; }
  if (/[|;&>]/.test(m[2])) return c.err("alias: pipes, redirects and chaining are not allowed in aliases");
  settings.aliases[m[1]] = m[2]; saveSettings(); c.write("alias " + m[1] + "='" + m[2] + "'", "success");
}, "alias gs='ls -l /system'");
def("unalias", "Core", "unalias <name>", "Remove an alias.", function (c) {
  if (!c.args[0]) return c.err("usage: unalias <name>");
  if (settings.aliases[c.args[0]] === undefined) return c.err("unalias: " + c.args[0] + ": not found");
  delete settings.aliases[c.args[0]]; saveSettings(); c.write("Removed alias " + c.args[0], "success");
});
def("which", "Core", "which <command>", "Show where a command lives.", function (c) {
  var n = (c.args[0] || "").toLowerCase();
  if (settings.aliases[n] !== undefined) { c.write(n + ": aliased to " + settings.aliases[n], "info"); return; }
  if (COMMANDS[n]) { c.write("/usr/bin/" + n, "success"); return; }
  c.write("command not found", "error"); return 1;
});
def("sh", "Core", "sh <script> | sh -c '<commands>'", "Run a virtual script file (or a quoted command string).", async function (c) {
  var text;
  if (c.args[0] === "-c") text = c.args.slice(1).join(" ");
  else { var src = readSources(c, c.args.slice(0, 1), "sh"); if (!src) return 1; text = src[0].text; }
  if ((c.s.depth || 0) >= 5) return c.err("sh: maximum script nesting depth reached");
  c.s.depth = (c.s.depth || 0) + 1;
  var ls = toLines(text).slice(0, 500);
  try { for (var i = 0; i < ls.length && !c.s.cancel; i++) { if (ls[i].trim()) await execLine(ls[i], c.s); } } finally { c.s.depth--; }
  return c.s.status;
}, "echo 'echo hi' > a.sh && sh a.sh");
defAlias("source", "sh"); defAlias("bash", "sh");

/* ======================= COMMANDS: Files ======================= */
def("pwd", "Files", "pwd", "Print the current virtual directory.", function (c) { c.write(c.s.cwd); });
def("cd", "Files", "cd [directory | - | ~]", "Change this terminal's working directory.", function (c) {
  var t = c.args[0] === "-" ? c.s.oldcwd : path(c.args[0] || "~", c.s.cwd);
  if (isFile(t)) return c.err("cd: not a directory: " + t);
  if (!isDir(t)) return c.err("cd: directory not found: " + t);
  c.s.oldcwd = c.s.cwd; c.s.cwd = t; if (c.s.id === activeId) updatePrompt();
});
def("ls", "Files", "ls [-alhR1] [path...]", "List directory contents (-l long, -a hidden, -h human sizes, -R recursive).", function (c) {
  var f = parseFlags(c.args), ops = f.o.length ? f.o : ["."], multi = ops.length > 1 || f.f.R;
  function row(e) {
    var nm = e.d ? e.name + "/" : e.name; if (!f.f.l) return nm;
    var sz = e.d ? "-" : (f.f.h ? humanSize(bytes(files[e.p])) : String(bytes(files[e.p])));
    return (e.d ? "drwxr-xr-x" : "-rw-r--r--") + " nova nova " + sz.padStart(9) + " " + fmtDate(meta[e.p] || Date.now()) + " " + nm;
  }
  function list(dir, label) {
    var l = children(dir).filter(function (e) { return f.f.a || e.name[0] !== "."; });
    if (label) c.write(label + ":", "info");
    if (!l.length) { if (!label) c.write("(empty)"); }
    l.forEach(function (e) { c.write(row(e), e.d ? "info" : ""); });
    if (f.f.R) l.forEach(function (e) { if (e.d) { c.write(""); list(e.p, e.p); } });
  }
  ops.forEach(function (op, i) {
    var p = path(op, c.s.cwd);
    if (isFile(p)) c.write(row({ p: p, name: op, d: false }));
    else if (isDir(p)) { if (i > 0) c.write(""); list(p, multi ? p : ""); }
    else c.err("ls: cannot access '" + op + "': No such file or directory");
  });
}, "ls -la /home/nova");
defAlias("dir", "ls", "Windows");
def("tree", "Files", "tree [-a] [-L depth] [path]", "Show a directory tree.", function (c) {
  var f = parseFlags(c.args, "L"), root = path(f.o[0] || ".", c.s.cwd), maxD = f.v.L ? parseInt(f.v.L, 10) : Infinity, dirs = 0, fl = 0;
  if (!isDir(root)) return c.err("tree: directory not found: " + root);
  c.write(root === "/" ? "/" : root + "/", "info");
  (function walk(dir, prefix, depth) {
    var kids = children(dir).filter(function (k) { return f.f.a || k.name[0] !== "."; });
    kids.forEach(function (k, i) {
      var last = i === kids.length - 1;
      c.write(prefix + (last ? "└── " : "├── ") + k.name + (k.d ? "/" : ""), k.d ? "info" : "");
      if (k.d) { dirs++; if (depth < maxD) walk(k.p, prefix + (last ? "    " : "│   "), depth + 1); } else fl++;
    });
  })(root, "", 1);
  c.write("\n" + dirs + " directories, " + fl + " files");
}, "tree -L 2 /home");
def("mkdir", "Files", "mkdir [-p] <directory...>", "Create virtual directories (-p creates parents).", function (c) {
  var f = parseFlags(c.args); if (!f.o.length) return c.err("usage: mkdir [-p] <directory...>");
  f.o.forEach(function (op) {
    var p = path(op, c.s.cwd);
    if (isFile(p)) return c.err("mkdir: " + op + ": a file with that name exists");
    if (isDir(p)) { if (!f.f.p) c.err("mkdir: " + op + ": already exists"); return; }
    if (!isDir(parent(p))) {
      if (!f.f.p) return c.err("mkdir: " + op + ": parent directory does not exist (use -p)");
      var chain = [], q = p; while (!isDir(q)) { chain.unshift(q); q = parent(q); }
      for (var i = 0; i < chain.length; i++) if (isFile(chain[i])) return c.err("mkdir: " + chain[i] + ": is a file");
      chain.forEach(fsMkdir);
    } else fsMkdir(p);
    c.write("Created directory " + p, "success");
  });
  persist(); eventFS("mkdir", "/");
}, "mkdir -p projects/web/css");
defAlias("md", "mkdir", "Windows");
def("rmdir", "Files", "rmdir <directory...>", "Remove empty directories.", function (c) {
  if (!c.args.length) return c.err("usage: rmdir <directory...>");
  c.args.forEach(function (op) {
    var p = path(op, c.s.cwd);
    if (!isDir(p) || p === "/") return c.err("rmdir: " + op + ": not a removable directory");
    if (children(p).length) return c.err("rmdir: " + op + ": directory not empty");
    fsRmdir(p); c.write("Removed directory " + p, "success");
  });
  fixCwds(); persist(); eventFS("rmdir", "/");
});
defAlias("rd", "rmdir", "Windows");
def("touch", "Files", "touch <file...>", "Create empty files, or update their modified time.", function (c) {
  if (!c.args.length) return c.err("usage: touch <file...>");
  c.args.forEach(function (op) {
    var p = path(op, c.s.cwd);
    if (exists(p)) { stamp(p); return; }
    if (!isDir(parent(p))) return c.err("touch: " + op + ": parent directory does not exist");
    files[p] = ""; stamp(p); c.write("Created file " + p, "success");
  });
  persist(); eventFS("create", "/");
});
def("write", "Files", "write <file> <text...>", "Replace a file's contents (creates it if needed).", function (c) {
  if (c.args.length < 2) return c.err("usage: write <file> <text>");
  var p = path(c.args[0], c.s.cwd);
  if (isDir(p)) return c.err("write: " + p + ": is a directory");
  if (!isDir(parent(p))) return c.err("write: parent directory does not exist");
  fsWrite(p, c.args.slice(1).join(" ")); c.write("Wrote " + p, "success");
});
def("append", "Files", "append <file> <text...>", "Add a line of text to the end of a file (creates it if needed).", function (c) {
  if (c.args.length < 2) return c.err("usage: append <file> <text>");
  var p = path(c.args[0], c.s.cwd), t = c.args.slice(1).join(" ");
  if (isDir(p) || !isDir(parent(p))) return c.err("append: cannot write to " + p);
  fsWrite(p, isFile(p) && files[p] !== "" ? files[p] + "\n" + t : t); c.write("Appended to " + p, "success");
});
def("cat", "Files", "cat [-n] [file...]", "Print files (or piped input); -n numbers lines.", function (c) {
  var f = parseFlags(c.args), src = readSources(c, f.o, "cat"); if (!src) return 1;
  src.forEach(function (x) { c.write(f.f.n ? toLines(x.text).map(function (l, i) { return String(i + 1).padStart(5) + "  " + l; }).join("\n") : x.text); });
}, "cat -n welcome.txt");
defAlias("type", "cat", "Windows"); defAlias("less", "cat"); defAlias("more", "cat");
def("head", "Files", "head [-n N] [file...]", "Show the first lines of a file (default 10).", function (c) {
  var f = parseFlags(c.args, "n"), n = f.v.n ? parseInt(f.v.n, 10) : 10, src = readSources(c, f.o, "head"); if (!src) return 1;
  src.forEach(function (x) { if (src.length > 1) c.write("==> " + x.name + " <==", "info"); c.write(toLines(x.text).slice(0, n).join("\n")); });
}, "head -n 3 notes.txt");
def("tail", "Files", "tail [-n N] [file...]", "Show the last lines of a file (default 10).", function (c) {
  var f = parseFlags(c.args, "n"), n = f.v.n ? parseInt(f.v.n, 10) : 10, src = readSources(c, f.o, "tail"); if (!src) return 1;
  src.forEach(function (x) { if (src.length > 1) c.write("==> " + x.name + " <==", "info"); c.write(n > 0 ? toLines(x.text).slice(-n).join("\n") : ""); });
});
def("wc", "Files", "wc [-lwc] [file...]", "Count lines, words and characters.", function (c) {
  var f = parseFlags(c.args), src = readSources(c, f.o, "wc"); if (!src) return 1;
  var any = f.f.l || f.f.w || f.f.c, tot = [0, 0, 0];
  function fmt(v, nm) { var parts = []; if (!any || f.f.l) parts.push(v[0]); if (!any || f.f.w) parts.push(v[1]); if (!any || f.f.c) parts.push(v[2]); return parts.map(function (x) { return String(x).padStart(6); }).join("") + (nm && nm !== "-" ? " " + nm : ""); }
  src.forEach(function (x) { var v = [toLines(x.text).length, x.text.split(/\s+/).filter(Boolean).length, x.text.length]; v.forEach(function (n, i) { tot[i] += n; }); c.write(fmt(v, x.name)); });
  if (src.length > 1) c.write(fmt(tot, "total"));
}, "cat welcome.txt | wc -w");
def("cp", "Files", "cp [-r] <source...> <destination>", "Copy files (or folders with -r).", function (c) {
  var f = parseFlags(c.args), o = f.o; if (o.length < 2) return c.err("usage: cp [-r] <source...> <destination>");
  var dst = path(o[o.length - 1], c.s.cwd), srcs = o.slice(0, -1);
  if (srcs.length > 1 && !isDir(dst)) return c.err("cp: target must be a directory when copying several items");
  srcs.forEach(function (op) {
    var src = path(op, c.s.cwd), d = dst;
    if (!exists(src)) return c.err("cp: " + op + ": No such file or directory");
    if (isDir(src) && !f.f.r) return c.err("cp: " + op + ": is a directory (use -r)");
    if (isDir(d)) d = path(base(src), d);
    if (src === d) return c.err("cp: source and destination are the same");
    if (isDir(src) && (d === src || under(d, src))) return c.err("cp: cannot copy a folder into itself");
    if (!isDir(parent(d))) return c.err("cp: destination directory not found");
    if (isDir(d) !== isDir(src) && exists(d)) return c.err("cp: cannot overwrite " + d + " with a different type");
    copyTree(src, d, false); c.write("Copied " + src + " -> " + d, "success");
  });
  persist(); eventFS("cp", "/");
}, "cp -r projects backup");
defAlias("copy", "cp", "Windows");
def("mv", "Files", "mv <source...> <destination>", "Move or rename files and folders.", function (c) {
  var o = c.args; if (o.length < 2) return c.err("usage: mv <source...> <destination>");
  var dst = path(o[o.length - 1], c.s.cwd), srcs = o.slice(0, -1);
  if (srcs.length > 1 && !isDir(dst)) return c.err("mv: target must be a directory when moving several items");
  srcs.forEach(function (op) {
    var src = path(op, c.s.cwd), d = dst;
    if (!exists(src) || src === "/") return c.err("mv: " + op + ": No such file or directory");
    if (isDir(d)) d = path(base(src), d);
    if (src === d) return;
    if (isDir(src) && under(d, src)) return c.err("mv: cannot move a folder into itself");
    if (!isDir(parent(d))) return c.err("mv: destination directory not found");
    if (exists(d) && isDir(d) !== isDir(src)) return c.err("mv: cannot overwrite " + d + " with a different type");
    copyTree(src, d, true); c.write("Moved " + src + " -> " + d, "success");
  });
  fixCwds(); persist(); eventFS("mv", "/");
}, "mv old.txt new.txt");
defAlias("move", "mv", "Windows"); defAlias("ren", "mv", "Windows");
def("rm", "Files", "rm [-rfv] <file-or-folder...>", "Delete virtual files; -r removes folders recursively, -f ignores missing items.", function (c) {
  var f = parseFlags(c.args); if (!f.o.length) return c.err("usage: rm [-rfv] <file-or-folder...>");
  f.o.forEach(function (op) {
    var p = path(op, c.s.cwd);
    if (p === "/") return c.err("rm: refusing to remove /");
    if (isFile(p)) { fsDelete(p); c.write("Removed " + p, "success"); return; }
    if (isDir(p)) {
      var kids = descendants(p);
      if (kids.length && !f.f.r) return c.err("rm: " + op + ": directory is not empty (use rm -r)");
      kids.slice().reverse().forEach(function (k) { if (isDir(k)) fsRmdir(k); else fsDelete(k); });
      fsRmdir(p); c.write("Removed directory " + p, "success"); return;
    }
    if (!f.f.f) c.err("rm: " + op + ": No such file or directory");
  });
  fixCwds(); persist(); eventFS("delete", "/");
}, "rm -r projects");
defAlias("del", "rm", "Windows"); defAlias("erase", "rm", "Windows");
def("find", "Files", "find [path] [-name pat] [-iname pat] [-type f|d] [text...]", "Search virtual paths by name pattern, type, or text.", function (c) {
  var a = c.args.slice(), root = "/", terms = [], name = null, iname = null, type = null, i;
  if (a.length && a[0][0] !== "-") { var p0 = path(a[0], c.s.cwd); if (isDir(p0)) { root = p0; a.shift(); } }
  for (i = 0; i < a.length; i++) { if (a[i] === "-name") name = a[++i]; else if (a[i] === "-iname") iname = a[++i]; else if (a[i] === "-type") type = a[++i]; else terms.push(a[i].toLowerCase()); }
  var list = descendants(root).filter(function (p) {
    if (type === "f" && !isFile(p)) return false; if (type === "d" && !isDir(p)) return false;
    if (name && !globToRe(name).test(base(p))) return false; if (iname && !globToRe(iname, true).test(base(p))) return false;
    return terms.every(function (t) { return p.toLowerCase().indexOf(t) >= 0; });
  });
  if (!list.length) { if (c.tty) c.write("No matches", "info"); return 1; }
  c.write(list.join("\n"));
}, "find /home -name '*.txt'");
def("stat", "Files", "stat <path...>", "Show details about a file or folder.", function (c) {
  if (!c.args.length) return c.err("usage: stat <path...>");
  c.args.forEach(function (op) {
    var p = path(op, c.s.cwd);
    if (isFile(p)) c.write("  File: " + p + "\n  Type: file\n  Size: " + bytes(files[p]) + " bytes (" + files[p].length + " chars, " + toLines(files[p]).length + " lines)\nModify: " + new Date(meta[p] || Date.now()).toString());
    else if (isDir(p)) c.write("  File: " + p + "\n  Type: directory\nItems: " + children(p).length + "\nModify: " + new Date(meta[p] || Date.now()).toString());
    else c.err("stat: " + op + ": No such file or directory");
  });
}, "stat welcome.txt");
def("file", "Files", "file <path...>", "Guess what kind of item a path is.", function (c) {
  if (!c.args.length) return c.err("usage: file <path...>");
  c.args.forEach(function (op) {
    var p = path(op, c.s.cwd), t;
    if (isDir(p)) t = "directory"; else if (!isFile(p)) return c.err("file: " + op + ": No such file or directory");
    else { var x = files[p]; if (x === "") t = "empty"; else { try { JSON.parse(x); t = "JSON text"; } catch (e) { t = /^#!/.test(x) ? "script text" : /<html|<!doctype/i.test(x) ? "HTML document" : "ASCII/UTF-8 text"; } } }
    c.write(op + ": " + t);
  });
});
def("du", "Files", "du [-hs] [path]", "Estimate space used by a folder.", function (c) {
  var f = parseFlags(c.args), p = path(f.o[0] || ".", c.s.cwd);
  if (!exists(p)) return c.err("du: " + p + ": No such file or directory");
  function size(d) { return isFile(d) ? bytes(files[d]) : Object.keys(files).filter(function (x) { return under(x, d); }).reduce(function (n, x) { return n + bytes(files[x]); }, 0); }
  function fmt(n) { return f.f.h ? humanSize(n) : String(n); }
  if (!f.f.s && isDir(p)) folders.filter(function (d) { return under(d, p); }).sort().forEach(function (d) { c.write(fmt(size(d)).padStart(10) + "  " + d); });
  c.write(fmt(size(p)).padStart(10) + "  " + p);
}, "du -h /home");
def("realpath", "Files", "realpath <path>", "Resolve a path to its absolute virtual path.", function (c) { c.write(path(c.args[0] || ".", c.s.cwd)); });
def("basename", "Files", "basename <path> [suffix]", "Show the last part of a path.", function (c) {
  if (!c.args[0]) return c.err("usage: basename <path> [suffix]");
  var b = base(path(c.args[0], c.s.cwd)); if (c.args[1] && b.slice(-c.args[1].length) === c.args[1] && b !== c.args[1]) b = b.slice(0, -c.args[1].length); c.write(b);
});
def("dirname", "Files", "dirname <path>", "Show the parent part of a path.", function (c) { if (!c.args[0]) return c.err("usage: dirname <path>"); c.write(parent(path(c.args[0], c.s.cwd))); });
def("chmod", "Files", "chmod <mode> <file...>", "Accepted for compatibility; permissions are not modelled.", function (c) { c.write("chmod: permissions are not modelled in NOVA's virtual filesystem (no change made).", "info"); });
defAlias("chown", "chmod");
def("edit", "Files", "edit <file>", "Open a virtual file in the NOVA Editor (creates it if missing).", function (c) {
  if (!c.args[0]) return c.err("usage: edit <file>");
  var p = path(c.args[0], c.s.cwd);
  if (isDir(p)) return c.err("edit: " + p + " is a directory");
  if (!isFile(p)) { if (!isDir(parent(p))) return c.err("edit: parent directory does not exist"); fsWrite(p, ""); c.write("Created " + p, "success"); }
  openEditor(p); c.write("Opened " + p + " in the Editor.", "info");
}, "edit notes.txt");
["nano", "vi", "vim", "code"].forEach(function (n) { defAlias(n, "edit"); });
def("download", "Files", "download <file>", "Save a virtual file to your real Downloads folder.", function (c) {
  if (!c.args[0]) return c.err("usage: download <file>");
  var src = readSources(c, c.args.slice(0, 1), "download"); if (!src || !src.length) return 1;
  downloadText(base(src[0].path), src[0].text); c.write("Downloading " + base(src[0].path) + " …", "success");
});
def("upload", "Files", "upload", "Import real text files from your Chromebook into the current folder.", function (c) {
  var dir = c.s.cwd, s = c.s;
  pickFiles(true, "", async function (list) {
    for (var i = 0; i < list.length; i++) {
      try { var t = await readFileText(list[i]), p = path(list[i].name, dir); fsWrite(p, t); print("Imported " + p + " (" + humanSize(bytes(t)) + ")", "success", s); }
      catch (e) { print("upload: " + (e.message || e), "error", s); }
    }
  });
  c.write("Choose files in the picker… (text files only)", "info");
});
def("backup", "Files", "backup", "Download the whole virtual workspace as a .json backup.", function (c) { doBackup(); c.write("Downloading backup…", "success"); });
def("restore", "Files", "restore", "Restore the virtual workspace from a .json backup.", function (c) { doRestore(c.s); c.write("Choose a NOVA backup (.json) in the picker…", "info"); });

/* ======================= COMMANDS: Text ======================= */
def("grep", "Text", "grep [-iInvcFlr] <pattern> [file...]", "Search text (regex) in files or piped input.", function (c) {
  var f = parseFlags(c.args), pat = f.o.shift(), re, esc = function (x) { return x.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); };
  if (pat === undefined) return c.err("usage: grep [-iInvcFlr] <pattern> [file...]");
  try { re = new RegExp(f.f.F ? esc(pat) : pat, f.f.i ? "i" : ""); } catch (e) { re = new RegExp(esc(pat), f.f.i ? "i" : ""); }
  var srcs;
  if (f.f.r) {
    srcs = []; (f.o.length ? f.o : ["."]).forEach(function (op) {
      var p = path(op, c.s.cwd);
      if (isFile(p)) srcs.push({ name: op, text: files[p] });
      else if (isDir(p)) descendants(p).filter(isFile).forEach(function (fp) { srcs.push({ name: fp, text: files[fp] }); });
      else c.err("grep: " + op + ": No such file or directory");
    });
  } else srcs = readSources(c, f.o, "grep");
  if (!srcs) return 1;
  var multi = srcs.length > 1 || f.f.r, any = false;
  srcs.forEach(function (x) {
    var n = 0;
    toLines(x.text).forEach(function (ln, i) {
      var hit = re.test(ln); if (f.f.v) hit = !hit;
      if (hit) { n++; any = true; if (!f.f.c && !f.f.l) c.write((multi ? x.name + ":" : "") + (f.f.n ? (i + 1) + ":" : "") + ln); }
    });
    if (f.f.c) c.write((multi ? x.name + ":" : "") + n);
    if (f.f.l && n) c.write(x.name);
  });
  if (!any) { if (c.tty && !f.f.c && !f.f.l) c.write("No matches", "info"); return 1; }
}, "grep -in welcome *.txt");
defAlias("findstr", "grep", "Windows");
def("sort", "Text", "sort [-rnuf] [file...]", "Sort lines (-r reverse, -n numeric, -u unique, -f ignore case).", function (c) {
  var f = parseFlags(c.args), src = readSources(c, f.o, "sort"); if (!src) return 1;
  var l = []; src.forEach(function (x) { l = l.concat(toLines(x.text)); });
  var key = function (x) { return f.f.f ? x.toLowerCase() : x; };
  l.sort(function (a, b) { if (f.f.n) return (parseFloat(a) || 0) - (parseFloat(b) || 0); a = key(a); b = key(b); return a < b ? -1 : a > b ? 1 : 0; });
  if (f.f.r) l.reverse();
  if (f.f.u) l = l.filter(function (x, i) { return i === 0 || key(x) !== key(l[i - 1]); });
  c.write(l.join("\n"));
}, "sort -n numbers.txt");
def("uniq", "Text", "uniq [-c] [-d] [file...]", "Collapse adjacent duplicate lines (-c counts, -d only duplicates).", function (c) {
  var f = parseFlags(c.args), src = readSources(c, f.o, "uniq"); if (!src) return 1;
  var out = [], cur = null, n = 0;
  function flush() { if (cur === null) return; if (f.f.d && n < 2) return; out.push(f.f.c ? String(n).padStart(6) + " " + cur : cur); }
  toLines(src[0].text).forEach(function (ln) { if (ln === cur) n++; else { flush(); cur = ln; n = 1; } });
  flush(); c.write(out.join("\n"));
}, "sort names.txt | uniq -c");
def("cut", "Text", "cut -d <delim> -f <fields> | -c <range> [file...]", "Extract columns from each line.", function (c) {
  var f = parseFlags(c.args, "dfc"), src = readSources(c, f.o, "cut"); if (!src) return 1;
  if (!f.v.f && !f.v.c) return c.err("cut: specify -f <fields> (with -d) or -c <range>");
  var d = f.v.d !== undefined ? f.v.d : "\t";
  src.forEach(function (x) { c.write(toLines(x.text).map(function (ln) {
    if (f.v.c) { var ch = ln.split(""); return rangeSpec(f.v.c, ch.length).map(function (i) { return ch[i - 1] || ""; }).join(""); }
    var parts = ln.split(d); return rangeSpec(f.v.f, parts.length).map(function (i) { return parts[i - 1]; }).filter(function (v) { return v !== undefined; }).join(d);
  }).join("\n")); });
}, "cut -d, -f1,3 data.csv");
def("tr", "Text", "tr [-d] <set1> [set2]", "Translate or delete characters from piped input.", function (c) {
  var f = parseFlags(c.args), s1 = f.o[0], s2 = f.o[1];
  if (c.stdin === null || s1 === undefined) return c.err("usage: <text> | tr [-d] <set1> [set2]");
  var a = expandSet(s1), b = s2 !== undefined ? expandSet(s2) : "";
  if (f.f.d) { c.write(c.stdin.split("").filter(function (ch) { return a.indexOf(ch) < 0; }).join("")); return; }
  if (!b) return c.err("tr: missing set2");
  c.write(c.stdin.split("").map(function (ch) { var i = a.indexOf(ch); return i < 0 ? ch : b[Math.min(i, b.length - 1)]; }).join(""));
}, "echo hello | tr a-z A-Z");
def("sed", "Text", "sed 's/old/new/[gi]' [file...]", "Substitute text in each line (the s/// command).", function (c) {
  var f = parseFlags(c.args), expr = f.o.shift();
  if (!expr || expr[0] !== "s" || expr.length < 4) return c.err("usage: sed 's/old/new/[gi]' [file...]");
  var dl = expr[1], parts = expr.slice(2).split(dl);
  if (parts.length < 2) return c.err("sed: malformed expression");
  var flags = (parts[2] || "").replace(/[^gi]/g, ""), re;
  try { re = new RegExp(parts[0], flags); } catch (e) { return c.err("sed: bad pattern"); }
  var src = readSources(c, f.o, "sed"); if (!src) return 1;
  src.forEach(function (x) { c.write(toLines(x.text).map(function (l) { return l.replace(re, parts[1]); }).join("\n")); });
}, "echo cat | sed 's/c/b/'");
def("nl", "Text", "nl [file...]", "Number lines.", function (c) { var src = readSources(c, c.args, "nl"); if (!src) return 1; src.forEach(function (x) { c.write(toLines(x.text).map(function (l, i) { return String(i + 1).padStart(6) + "  " + l; }).join("\n")); }); });
def("rev", "Text", "rev [file...]", "Reverse each line's characters.", function (c) { var src = readSources(c, c.args, "rev"); if (!src) return 1; src.forEach(function (x) { c.write(toLines(x.text).map(function (l) { return l.split("").reverse().join(""); }).join("\n")); }); });
def("tac", "Text", "tac [file...]", "Print lines in reverse order.", function (c) { var src = readSources(c, c.args, "tac"); if (!src) return 1; src.forEach(function (x) { c.write(toLines(x.text).reverse().join("\n")); }); });
def("tee", "Text", "tee [-a] <file>", "Save piped input to a file and also pass it on.", function (c) {
  var f = parseFlags(c.args); if (c.stdin === null || !f.o[0]) return c.err("usage: <text> | tee [-a] <file>");
  var p = path(f.o[0], c.s.cwd); if (isDir(p) || !isDir(parent(p))) return c.err("tee: cannot write to " + p);
  fsWrite(p, f.f.a && isFile(p) && files[p] !== "" ? files[p] + "\n" + c.stdin : c.stdin); c.write(c.stdin);
}, "ls | tee list.txt");
def("diff", "Text", "diff <file1> <file2>", "Compare two files line by line.", function (c) {
  if (c.args.length < 2) return c.err("usage: diff <file1> <file2>");
  var src = readSources(c, c.args.slice(0, 2), "diff"); if (!src || src.length < 2) return 1;
  var a = toLines(src[0].text), b = toLines(src[1].text);
  if (a.length > 1000 || b.length > 1000) return c.err("diff: files too large for the simulator (max 1000 lines)");
  var d = diffLines(a, b); if (!d.length) { c.write("Files are identical.", "success"); return 0; }
  c.write(d.join("\n")); return 1;
});
def("seq", "Text", "seq [first] <last> [step]", "Print a sequence of numbers.", function (c) {
  var n = c.args.map(parseFloat); if (!n.length || n.some(isNaN)) return c.err("usage: seq [first] <last> [step]");
  var a = n.length === 1 ? 1 : n[0], b = n.length === 1 ? n[0] : n[1], st = n[2] || (a <= b ? 1 : -1), out = [];
  if (st === 0 || (b - a) / st > 10000) return c.err("seq: unreasonable range"); for (var v = a; st > 0 ? v <= b : v >= b; v += st) out.push(v);
  c.write(out.join("\n"));
}, "seq 1 2 9");
def("base64", "Text", "base64 [-d] [text | file]", "Encode or decode Base64 text.", function (c) {
  var f = parseFlags(c.args), t;
  if (f.o.length) { var p = path(f.o[0], c.s.cwd); t = isFile(p) ? files[p] : f.o.join(" "); } else if (c.stdin !== null) t = c.stdin; else return c.err("usage: base64 [-d] <text|file>");
  try { c.write(f.f.d ? decodeURIComponent(escape(atob(t.trim()))) : btoa(unescape(encodeURIComponent(t)))); } catch (e) { return c.err("base64: invalid input"); }
}, "echo hello | base64");
def("sha256", "Text", "sha256 [text | file]", "Compute a SHA-256 hash.", async function (c) {
  var t, p = c.args[0] ? path(c.args[0], c.s.cwd) : "";
  if (c.args.length) t = isFile(p) ? files[p] : c.args.join(" "); else if (c.stdin !== null) t = c.stdin; else return c.err("usage: sha256 <text|file>");
  if (!window.crypto || !crypto.subtle) return c.err("sha256: Web Crypto is not available in this browser context");
  var buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(t));
  c.write(Array.prototype.map.call(new Uint8Array(buf), function (b) { return b.toString(16).padStart(2, "0"); }).join(""));
});

/* ======================= COMMANDS: System ======================= */
function pageInfo() { return { cores: navigator.hardwareConcurrency || "unknown", mem: navigator.deviceMemory ? navigator.deviceMemory + " GB (approx.)" : "not reported", online: navigator.onLine }; }
function browserName() { var u = navigator.userAgent, m = /(Edg|Chrome|CriOS|Firefox|Safari)\/([\d.]+)/.exec(u); return m ? m[1].replace("Edg", "Edge") + " " + m[2].split(".")[0] : u; }
function uptimeText() { var sec = Math.floor((Date.now() - start) / 1000); return Math.floor(sec / 3600) + "h " + Math.floor(sec % 3600 / 60) + "m " + sec % 60 + "s"; }
def("whoami", "System", "whoami", "Print the current user.", function (c) { c.write("nova"); });
def("id", "System", "id", "Show the simulated user and group IDs.", function (c) { c.write("uid=1000(nova) gid=1000(nova) groups=1000(nova),27(sudo)"); });
def("groups", "System", "groups", "Show simulated group membership.", function (c) { c.write("nova sudo"); });
def("hostname", "System", "hostname", "Print the host name.", function (c) { c.write("nova-chromebook"); });
def("uname", "System", "uname [-a|-s|-r|-n|-m]", "Print system information.", function (c) {
  var f = parseFlags(c.args);
  if (f.f.a) c.write("NOVA nova-chromebook " + VERSION + " NovaCore browser-sim");
  else if (f.f.s) c.write("NOVA"); else if (f.f.r) c.write(VERSION); else if (f.f.n) c.write("nova-chromebook"); else if (f.f.m) c.write("browser-sim"); else c.write(KERNEL);
});
def("date", "System", "date [+format]", "Show the date and time (e.g. date +%F).", function (c) { var f = c.args[0]; c.write(f && f[0] === "+" ? tfmt(new Date(), f.slice(1)) : new Date().toString()); }, "date +%A");
def("uptime", "System", "uptime", "Show how long this NOVA session has been running.", function (c) { c.write("up " + uptimeText()); });
def("cal", "System", "cal [month] [year]", "Show a calendar (default: this month).", function (c) {
  var now = new Date(), m = c.args.length > 1 ? parseInt(c.args[0], 10) - 1 : now.getMonth(), y = parseInt(c.args[c.args.length > 1 ? 1 : 0], 10) || now.getFullYear();
  if (!(m >= 0 && m < 12)) return c.err("cal: month must be 1-12");
  var names = ["January","February","March","April","May","June","July","August","September","October","November","December"], title = names[m] + " " + y;
  var out = [" ".repeat(Math.max(0, Math.floor((20 - title.length) / 2))) + title, "Su Mo Tu We Th Fr Sa"], first = new Date(y, m, 1).getDay(), days = new Date(y, m + 1, 0).getDate(), row = "   ".repeat(first);
  for (var d = 1; d <= days; d++) { row += String(d).padStart(2) + " "; if ((first + d) % 7 === 0) { out.push(row.trimEnd()); row = ""; } }
  if (row) out.push(row.trimEnd());
  c.write(out.join("\n") + (m === now.getMonth() && y === now.getFullYear() ? "\n\nToday is " + tfmt(now, "%A, %B %d, %Y") : ""));
});
def("ps", "System", "ps", "List simulated processes.", function (c) {
  var l = ["PID   PROCESS", "1     NovaCore (simulated)", "2     NovaShell", "3     VirtualFS", "4     WindowManager"];
  sessions.forEach(function (s, i) { l.push((10 + i) + "    " + SHELL + " tty" + s.id + (s.running ? " [running]" : "")); }); c.write(l.join("\n"));
});
defAlias("tasklist", "ps", "Windows");
def("top", "System", "top", "Show a simulated system monitor snapshot.", function (c) {
  var pm = performance && performance.memory ? Math.round(performance.memory.usedJSHeapSize / 1048576) + " MB JS heap (browser-reported)" : "browser-managed";
  c.write("NOVA SYSTEM MONITOR\nUptime: " + uptimeText() + "\nCPU: browser-managed (" + pageInfo().cores + " logical cores reported)\nMemory: " + pm + "\nSessions: " + sessions.length + "\nVirtual files: " + Object.keys(files).length);
});
def("kill", "System", "kill <pid>", "Send a signal to a simulated process (no real effect).", function (c) { if (!c.args[0]) return c.err("usage: kill <pid>"); c.write("kill: " + c.args[0] + ": simulated processes cannot be terminated.", "warning"); });
def("free", "System", "free", "Show memory information reported by the browser.", function (c) {
  var pm = performance && performance.memory;
  c.write("Browser-reported memory (not real hardware data):\nDevice memory: " + pageInfo().mem + (pm ? "\nJS heap used: " + humanSize(pm.usedJSHeapSize) + " / " + humanSize(pm.jsHeapSizeLimit) : ""));
});
def("df", "System", "df [-h]", "Show virtual disk usage (5 MB browser quota assumed).", function (c) {
  var used = totalBytes(), quota = 5 * 1048576, h = parseFlags(c.args).f.h, fm = function (n) { return h ? humanSize(n) : String(n); };
  c.write("Filesystem      Size       Used       Avail   Use%\nNOVA-VirtualFS  " + fm(quota).padEnd(10) + " " + fm(used).padEnd(10) + " " + fm(Math.max(0, quota - used)).padEnd(10) + " " + Math.min(100, Math.round(used / quota * 100)) + "%  (simulated)");
});
def("env", "System", "env", "List environment variables for this session.", function (c) { var e = getEnv(c.s); c.write(Object.keys(e).sort().map(function (k) { return k + "=" + e[k]; }).join("\n")); });
def("printenv", "System", "printenv [NAME]", "Print one or all environment variables.", function (c) {
  var e = getEnv(c.s); if (!c.args[0]) { c.write(Object.keys(e).sort().map(function (k) { return k + "=" + e[k]; }).join("\n")); return; }
  if (e[c.args[0]] === undefined) return 1; c.write(e[c.args[0]]);
});
def("export", "System", "export KEY=value...", "Set session environment variables (also: KEY=value).", function (c) {
  if (!c.args.length) return c.err("usage: export KEY=value");
  c.args.forEach(function (a) { var m = /^([A-Za-z_]\w*)=(.*)$/.exec(a); if (!m) return c.err("export: invalid assignment '" + a + "'"); c.s.env[m[1]] = m[2]; c.write("Set " + m[1], "success"); });
}, "export GREETING=hi && echo $GREETING");
def("unset", "System", "unset <NAME...>", "Remove session environment variables.", function (c) { c.args.forEach(function (n) { delete c.s.env[n]; }); });
def("clearenv", "System", "clearenv", "Clear all variables set in this session.", function (c) { c.s.env = {}; c.write("Session environment cleared."); });
def("lscpu", "System", "lscpu", "Show CPU details the browser exposes.", function (c) { c.write("Architecture:   browser-simulated\nLogical cores:  " + pageInfo().cores + "\nPlatform:       " + (navigator.platform || "unknown") + "\n(only what the browser reports; no real hardware access)"); });
def("display", "System", "display", "Show screen and window size.", function (c) { c.write("Window:  " + innerWidth + " x " + innerHeight + "\nScreen:  " + window.screen.width + " x " + window.screen.height + "\nPixel ratio: " + devicePixelRatio + "\nTheme accent: " + settings.accent + "  Density: " + settings.density); });
def("locale", "System", "locale", "Show language and time zone.", function (c) { c.write("Language: " + (navigator.language || "unknown") + "\nTime zone: " + (Intl.DateTimeFormat().resolvedOptions().timeZone || "unknown")); });
def("battery", "System", "battery", "Show battery status if the browser exposes it.", async function (c) {
  if (!navigator.getBattery) return c.err("battery: this browser does not expose battery information");
  var b = await navigator.getBattery(); c.write("Level: " + Math.round(b.level * 100) + "%\nCharging: " + (b.charging ? "yes" : "no"));
});
def("netinfo", "Network", "netinfo", "Show the connection details the browser reports.", function (c) {
  var cn = navigator.connection || {}; c.write("Online: " + (navigator.onLine ? "yes" : "no") + "\nType: " + (cn.effectiveType || "not reported") + "\nDownlink: " + (cn.downlink ? cn.downlink + " Mbit/s (estimate)" : "not reported") + "\nRound-trip: " + (cn.rtt ? cn.rtt + " ms (estimate)" : "not reported") + "\n(real interfaces and IP addresses are not visible to web pages)");
});
def("neofetch", "System", "neofetch", "Show a system summary with the NOVA logo.", function (c) {
  var logo = ["   _   _  ", "  | \\ | | ", "  |  \\| | ", "  | |\\  | ", "  |_| \\_| ", "          "];
  var info = ["nova@nova-chromebook", "--------------------", "OS: NOVA OS " + VERSION, "Kernel: " + KERNEL, "Shell: " + SHELL, "Uptime: " + uptimeText(), "Browser: " + browserName(), "Accent: " + settings.accent + " · " + settings.density, "Files: " + Object.keys(files).length + " · Sessions: " + sessions.length];
  c.write(info.map(function (l, i) { return (logo[i] !== undefined ? logo[i] : "          ") + "  " + l; }).join("\n"), "success");
});
def("reboot", "System", "reboot", "Reload the simulator (files are kept).", function (c) { c.write("Simulating reboot...", "success"); setTimeout(function () { location.reload(); }, 500); });
def("systemctl", "System", "systemctl status", "Simulated service status.", function (c) { c.write(c.args[0] === "status" ? "nova-simulator.service — active (simulated)" : "Try systemctl status (simulation only).", "info"); });
def("journalctl", "System", "journalctl", "Show the simulator's event log for this page load.", function (c) { c.write(sysLog.join("\n") || "(no entries)", "info"); });
def("lsb_release", "System", "lsb_release", "Show distribution info.", function (c) { c.write("Distributor ID: NOVA\nDescription: NOVA OS " + VERSION + " Chromebook Edition\nRelease: " + VERSION, "info"); });
def("hostnamectl", "System", "hostnamectl", "Show host information.", function (c) { c.write("Static hostname: nova-chromebook\nOperating System: NOVA OS " + VERSION + " (simulated)\nKernel: " + KERNEL + "\nArchitecture: browser-simulated", "info"); });

/* ======================= COMMANDS: Customize ======================= */
def("theme", "Customize", "theme [list | <name> | #rrggbb]", "Change the accent colour.", function (c) {
  var a = (c.args[0] || "").toLowerCase();
  if (!a || a === "list") { c.write("Current accent: " + settings.accent + "\nAvailable: " + Object.keys(ACCENTS).join(", ") + "\nOr use a hex colour, e.g. theme #ff8800", "info"); return; }
  var col = ACCENTS[a] || (colorOk(a) ? a : null); if (!col) return c.err("theme: unknown colour '" + a + "'. Try theme list.");
  setSetting("accent", col); c.write("Accent set to " + col, "success");
}, "theme blue");
def("density", "Customize", "density [comfortable|compact]", "Change interface spacing.", function (c) {
  var a = (c.args[0] || "").toLowerCase(); if (!a) { c.write("Density: " + settings.density, "info"); return; }
  if (a !== "comfortable" && a !== "compact") return c.err("density: choose comfortable or compact");
  setSetting("density", a); c.write("Density set to " + a, "success");
});
def("font", "Customize", "font <term|editor> <size 10-28>", "Change terminal or editor font size.", function (c) {
  var w = (c.args[0] || "").toLowerCase(), n = parseInt(c.args[1], 10);
  if ((w !== "term" && w !== "editor") || isNaN(n)) { c.write("Terminal: " + settings.termFont + "px  Editor: " + settings.editorFont + "px\nUsage: font <term|editor> <size>", "info"); return; }
  if (n < 10 || n > 28) return c.err("font: size must be between 10 and 28");
  setSetting(w === "term" ? "termFont" : "editorFont", n); c.write("Set " + w + " font to " + n + "px", "success");
}, "font term 15");
def("settings", "Customize", "settings [reset | set <key> <value>]", "Show or change saved settings.", function (c) {
  var a = c.args[0];
  if (a === "reset") { var al = settings.aliases, pk = settings.packages; settings = settingsDefault(); settings.aliases = al; settings.packages = pk; saveSettings(); applySettings(); c.write("Appearance/terminal/editor settings reset (aliases kept).", "success"); return; }
  if (a === "set") {
    var k = c.args[1], v = c.args[2], num = { termFont: 1, editorFont: 1 }, bool = { editorWrap: 1, confirmDelete: 1 };
    if (k === "accent") { var col = ACCENTS[(v || "").toLowerCase()] || v; if (!colorOk(col)) return c.err("settings: accent must be a name or #rrggbb"); setSetting("accent", col); }
    else if (k === "density") { if (v !== "comfortable" && v !== "compact") return c.err("settings: density must be comfortable or compact"); setSetting("density", v); }
    else if (num[k]) { var n = parseInt(v, 10); if (!(n >= 10 && n <= 28)) return c.err("settings: size must be 10-28"); setSetting(k, n); }
    else if (bool[k]) { if (v !== "true" && v !== "false") return c.err("settings: use true or false"); setSetting(k, v === "true"); }
    else return c.err("settings: unknown key. Keys: accent, density, termFont, editorFont, editorWrap, confirmDelete");
    c.write("Saved " + k + " = " + v, "success"); return;
  }
  c.write(["accent        " + settings.accent, "density       " + settings.density, "termFont      " + settings.termFont, "editorFont    " + settings.editorFont, "editorWrap    " + settings.editorWrap, "confirmDelete " + settings.confirmDelete, "aliases       " + Object.keys(settings.aliases).length, "", "Change with: settings set <key> <value>"].join("\n"));
});
def("open", "Customize", "open <terminal|files|editor|system|settings>", "Switch to a NOVA app.", function (c) {
  var m = { terminal: "terminal-area", files: "files-area", editor: "editor-area", system: "system-area", settings: "settings-area" }, a = (c.args[0] || "").toLowerCase();
  if (!m[a]) return c.err("usage: open <terminal|files|editor|system|settings>"); app(m[a]); c.write("Opened " + a, "info");
});
def("reset", "Customize", "reset", "Restore starter files and settings (asks for confirmation).", function (c) { if (!resetWorkspace()) c.write("Reset cancelled.", "info"); });

/* ======================= COMMANDS: Productivity ======================= */
function todoLines() { return isFile(HOME + "/todo.txt") ? toLines(files[HOME + "/todo.txt"]) : []; }
function saveTodo(l) { fsWrite(HOME + "/todo.txt", l.join("\n")); }
def("todo", "Productivity", "todo [add <text> | list | done <n> | rm <n> | clear]", "A tiny to-do list stored in /home/nova/todo.txt.", function (c) {
  var a = (c.args[0] || "list").toLowerCase(), l = todoLines(), n = parseInt(c.args[1], 10);
  if (a === "add") { var t = c.args.slice(1).join(" "); if (!t) return c.err("usage: todo add <text>"); l.push("[ ] " + t); saveTodo(l); c.write("Added #" + l.length, "success"); }
  else if (a === "list") c.write(l.length ? l.map(function (x, i) { return (i + 1) + ". " + x; }).join("\n") : "Nothing to do. Add one with: todo add <text>");
  else if (a === "done" || a === "rm") {
    if (!(n >= 1 && n <= l.length)) return c.err("todo: no item #" + c.args[1]);
    if (a === "done") l[n - 1] = l[n - 1].replace(/^\[.\]/, "[x]"); else l.splice(n - 1, 1);
    saveTodo(l); c.write(a === "done" ? "Marked #" + n + " done" : "Removed #" + n, "success");
  } else if (a === "clear") { saveTodo(l.filter(function (x) { return x.indexOf("[x]") !== 0; })); c.write("Cleared completed items.", "success"); }
  else return c.err("usage: todo [add <text> | list | done <n> | rm <n> | clear]");
}, "todo add buy milk");
def("note", "Productivity", "note <text>", "Append a timestamped line to /home/nova/notes.txt.", function (c) {
  var t = c.args.join(" "); if (!t) return c.err("usage: note <text>");
  var p = HOME + "/notes.txt"; fsWrite(p, (isFile(p) && files[p] !== "" ? files[p] + "\n" : "") + "[" + tfmt(new Date(), "%F %H:%M") + "] " + t); c.write("Note saved.", "success");
});
def("calc", "Productivity", "calc <expression>", "Calculator: + - * / % ^, parentheses, sqrt sin cos log ln abs round min max, pi, e.", function (c) {
  try { var v = calcExpr(c.args.join(" ")); if (!isFinite(v)) throw new Error("result is not finite"); c.write(String(Math.round(v * 1e10) / 1e10)); } catch (e) { return c.err("calc: " + e.message); }
}, "calc (2+3)*sqrt(16)");
defAlias("expr", "calc"); defAlias("bc", "calc");
def("timer", "Productivity", "timer <seconds> [message]", "Count down, then print a message (Ctrl+C cancels).", async function (c) {
  var n = parseFloat(c.args[0]); if (!(n > 0)) return c.err("usage: timer <seconds> [message]");
  var msg = c.args.slice(1).join(" ") || "Time is up!"; c.write("Timer started: " + n + "s", "info");
  await sleepMs(Math.min(n, 3600) * 1000, c.s);
  if (c.s.cancel) { c.write("Timer cancelled.", "warning"); return 130; }
  c.write("⏰ " + msg, "success");
}, "timer 30 stretch");
def("random", "Productivity", "random [min] [max]", "Print a random integer (default 1-100).", function (c) {
  var a = c.args.length > 1 ? parseInt(c.args[0], 10) : 1, b = c.args.length > 1 ? parseInt(c.args[1], 10) : (parseInt(c.args[0], 10) || 100);
  if (isNaN(a) || isNaN(b) || a > b) return c.err("usage: random [min] [max]"); c.write(String(a + Math.floor(Math.random() * (b - a + 1))));
});
def("uuid", "Productivity", "uuid", "Generate a random UUID.", function (c) {
  c.write(window.crypto && crypto.randomUUID ? crypto.randomUUID() : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (ch) { var r = Math.random() * 16 | 0; return (ch === "x" ? r : (r & 3 | 8)).toString(16); }));
});

/* ======================= COMMANDS: Fun ======================= */
var QUOTES = ["Small steps still move you forward.", "Make it work, make it right, make it fast.", "A clean desk is a sign of a recent reboot.", "The best bug report includes how to reproduce it.", "Ctrl+Z is a time machine.", "Simple is hard to build and easy to use.", "Measure twice, commit once.", "Every expert was once a beginner with a terminal."];
def("fortune", "Fun", "fortune", "Print a random saying.", function (c) { c.write(QUOTES[Math.floor(Math.random() * QUOTES.length)], "info"); });
def("cowsay", "Fun", "cowsay <text>", "A cow says your text.", function (c) {
  var t = c.args.join(" ") || (c.stdin || "Moo!"), l = t.split("\n").slice(0, 6), w = Math.max.apply(null, l.map(function (x) { return x.length; }));
  c.write(" " + "_".repeat(w + 2) + "\n" + l.map(function (x) { return "< " + x.padEnd(w) + " >"; }).join("\n") + "\n " + "-".repeat(w + 2) + "\n        \\   ^__^\n         \\  (oo)\\_______\n            (__)\\       )\\/\\\n                ||----w |\n                ||     ||", "success");
}, "cowsay hello");

/* ======================= COMMANDS: Packages ======================= */
function installed() { return BASE_PACKAGES.concat(settings.packages); }
function pkgCmd(c, kind) {
  var a = c.args[0], x = c.args.slice(1).filter(function (v) { return v[0] !== "-"; }), apt = kind === "apt";
  var isInstall = apt ? a === "install" : (a === "-S" || a === "-Sy");
  var isRemove = apt ? (a === "remove" || a === "purge") : a === "-R";
  var isList = apt ? (a === "list" || a === "--list") : (a === "-Q" || a === "-Qe");
  if (a === "update" || a === "-Sy" || a === "upgrade" || a === "-Syu") { c.write("Package indexes refreshed (simulation only; nothing downloaded).", "info"); return; }
  if (isList) { c.write("Simulated packages:\n" + installed().map(function (p) { return p + (BASE_PACKAGES.indexOf(p) >= 0 ? " " + VERSION : " 1.0 (simulated)"); }).join("\n"), "info"); return; }
  if (isInstall) {
    if (!x.length) return c.err(kind + ": specify a package name");
    x.forEach(function (n) { if (!/^[a-z0-9][a-z0-9+.\-]*$/i.test(n)) return c.err(kind + ": invalid package name '" + n + "'"); if (installed().indexOf(n) >= 0) c.write(n + " is already installed.", "info"); else { settings.packages.push(n); c.write("Simulation only: no package downloaded. Recorded '" + n + "' as installed.", "info"); } });
    saveSettings(); return;
  }
  if (isRemove) {
    x.forEach(function (n) { if (BASE_PACKAGES.indexOf(n) >= 0) return c.err(kind + ": " + n + " is a core NOVA package and cannot be removed"); var i = settings.packages.indexOf(n); if (i < 0) return c.err(kind + ": " + n + " is not installed"); settings.packages.splice(i, 1); c.write("Removed " + n + " (simulated).", "info"); });
    saveSettings(); return;
  }
  if (a === "search" || a === "-Ss") { c.write(BASE_PACKAGES.filter(function (p) { return p.indexOf(x[0] || "") >= 0; }).join("\n") || "No simulated packages match.", "info"); return; }
  if (a === "show" && x[0]) { c.write("Package: " + x[0] + "\nStatus: " + (installed().indexOf(x[0]) >= 0 ? "installed (simulated)" : "not installed"), "info"); return; }
  c.write(kind + " is simulated. Try: " + (apt ? "apt list | apt install <name> | apt remove <name> | apt search <word>" : "pacman -Q | pacman -S <name> | pacman -R <name> | pacman -Ss <word>"), "info");
}
def("apt", "Packages", "apt list | update | upgrade | search <w> | show <n> | install <n> | remove <n>", "Ubuntu/Debian-style package manager simulation.", function (c) { return pkgCmd(c, "apt"); });
def("pacman", "Packages", "pacman -Q | -S <n> | -R <n> | -Ss <w> | -Syu", "Arch-style package manager simulation.", function (c) { return pkgCmd(c, "pacman"); });
def("dpkg", "Packages", "dpkg -l", "List simulated installed packages.", function (c) { c.args = ["list"]; return pkgCmd(c, "apt"); });
["python", "python3", "node", "npm", "pip", "git"].forEach(function (n) {
  def(n, "Packages", n + " [...]", "Not installed in the simulated shell (does not affect your Chromebook apps).", function (c) { c.write(n + " is not installed in the simulated shell; this does not affect your Chromebook apps.", "warning"); return 127; });
});

/* ======================= COMMANDS: ChromeOS / Windows / Network ======================= */
def("crosh", "ChromeOS", "crosh", "Show a ChromeOS-style simulated command reference.", function (c) { c.write("CROSH-STYLE SIMULATION\nhelp\nhelp_advanced\nnetwork_diag\nvmc list\nshell\nThis is not Google's real crosh. Press Ctrl + Alt + T on your Chromebook for the real one.", "info"); });
defAlias("help_advanced", "crosh");
def("network_diag", "ChromeOS", "network_diag", "Simulated network diagnostics pointer.", function (c) { c.write("network_diag is a real crosh tool and cannot be run from a webpage.\nUse netinfo for what the browser reports, or open real crosh with Ctrl + Alt + T.", "warning"); });
def("vmc", "ChromeOS", "vmc list", "Simulated virtual machine list.", function (c) { c.write(c.args[0] === "list" ? "No simulated virtual machines registered." : "Usage: vmc list (simulation only)", "info"); });
def("shell", "ChromeOS", "shell", "Explain why the real ChromeOS shell is unreachable.", function (c) { c.write("A webpage cannot open the real ChromeOS shell. This is a simulation.", "warning"); });
def("open-crosh", "ChromeOS", "open-crosh", "How to open the real crosh terminal.", function (c) { c.write("NOVA cannot launch or control the built-in crosh terminal from a webpage.", "warning"); c.write("On your Chromebook, press Ctrl + Alt + T to open crosh separately.", "info"); });
def("ver", "Windows", "ver", "Windows-style version line.", function (c) { c.write("NOVA OS [Version " + VERSION + "] (Windows-style simulated output)"); });
def("systeminfo", "Windows", "systeminfo", "Windows-style system summary.", function (c) { c.write("Host Name: NOVA-CHROMEBOOK\nOS Name: NOVA OS " + VERSION + "\nSystem Type: Browser simulator\nTerminal Sessions: " + sessions.length + "\nVirtual Files: " + Object.keys(files).length); });
def("where", "Windows", "where <command>", "Windows-style command lookup.", function (c) { var n = (c.args[0] || "").toLowerCase(); if (COMMANDS[n]) c.write("C:\\NOVA\\System32\\" + n + ".sim", "info"); else { c.write("Could not find command.", "error"); return 1; } });
def("ping", "Network", "ping <host>", "Explains why real ping isn't available here.", function (c) {
  c.write("Real ping is not available inside this browser terminal. ChromeOS keeps web pages isolated from crosh and the system shell.", "warning");
  c.write("To run a real network test, open the ChromeOS crosh window with Ctrl + Alt + T, then enter: ping " + (c.args[0] || "example.com"), "info");
  c.write("NOVA cannot send commands to crosh or read its output. This is a ChromeOS security boundary.", "info");
});
def("ipconfig", "Network", "ipconfig", "Simulated; shows browser-reported connection info.", function (c) { c.write("ipconfig is simulated; this browser app cannot inspect real network interfaces.", "warning"); return c.exec(["netinfo"]); });
defAlias("ifconfig", "ipconfig"); defAlias("ip", "ipconfig");
def("curl", "Network", "curl <url>", "Simulated; web pages cannot run system network commands.", function (c) { c.write("curl is simulated; this browser app cannot perform system network commands.", "warning"); });
defAlias("wget", "curl");


/* ---------- NOVA 7.4.0 extended customization + utility commands ---------- */
def("wallpaper", "Customize", "wallpaper <aurora|midnight|grid|nebula>", "Change the desktop background preset.", function (c) {
  var v = (c.args[0] || "").toLowerCase();
  if (!v || v === "list") { c.write("Available wallpapers: aurora, midnight, grid, nebula\nCurrent: " + (settings.wallpaper || "aurora")); return; }
  if (["aurora","midnight","grid","nebula"].indexOf(v) < 0) return c.err("wallpaper: choose aurora, midnight, grid, or nebula");
  setSetting("wallpaper", v); c.write("Workspace background set to " + v + ".", "success");
}, "wallpaper nebula");
def("prompt", "Customize", "prompt <classic|minimal|power>", "Change the terminal prompt style.", function (c) {
  var v = (c.args[0] || "").toLowerCase();
  if (!v || v === "list") { c.write("Prompt styles: classic, minimal, power\nCurrent: " + (settings.promptStyle || "classic")); return; }
  if (["classic","minimal","power"].indexOf(v) < 0) return c.err("prompt: choose classic, minimal, or power");
  setSetting("promptStyle", v); updatePrompt(); c.write("Prompt style set to " + v + ".", "success");
}, "prompt minimal");
def("fontface", "Customize", "fontface <mono|modern|retro>", "Change the terminal typeface preset.", function (c) {
  var v = (c.args[0] || "").toLowerCase();
  if (!v || v === "list") { c.write("Font presets: mono, modern, retro\nCurrent: " + (settings.fontFace || "mono")); return; }
  if (["mono","modern","retro"].indexOf(v) < 0) return c.err("fontface: choose mono, modern, or retro");
  setSetting("fontFace", v); c.write("Terminal font preset set to " + v + ".", "success");
}, "fontface retro");
def("settitle", "Customize", "settitle <terminal name>", "Rename the active terminal tab.", function (c) {
  var n = c.args.join(" ").trim(); if (!n) return c.err("usage: settitle <terminal name>");
  c.s.name = n.slice(0, 32); drawTabs(); c.write("Terminal tab renamed to " + c.s.name + ".", "success");
}, "settitle Development");
def("mkalias", "Customize", "mkalias <name> <command>", "Create a persistent shortcut alias.", function (c) {
  var n = (c.args.shift() || "").toLowerCase(), v = c.args.join(" ");
  if (!/^[a-z][a-z0-9_-]*$/.test(n) || !v) return c.err("usage: mkalias <name> <command>");
  if (COMMANDS[n] || ["sudo","cd","exit"].indexOf(n) >= 0) return c.err("mkalias: that command name is reserved");
  settings.aliases[n] = v; saveSettings(); c.write("Alias created: " + n + "='" + v + "'", "success");
}, "mkalias projects 'cd ~/projects'");
def("unaliasall", "Customize", "unaliasall", "Remove all custom aliases and restore the defaults.", function (c) {
  settings.aliases = { ll: "ls -l", la: "ls -la", l: "ls -l", "..": "cd .." }; saveSettings();
  c.write("Aliases restored to defaults.", "success");
});
def("mkcd", "Files", "mkcd <directory>", "Create a directory and enter it.", function (c) {
  var p = path(c.args[0], c.s.cwd);
  if (!c.args[0]) return c.err("usage: mkcd <directory>");
  if (exists(p)) return c.err("mkcd: path already exists: " + p);
  var cur = "", parts = p.split("/").filter(Boolean);
  parts.forEach(function (part) { cur += "/" + part; if (!isDir(cur)) fsMkdir(cur); });
  persist(); c.s.oldcwd = c.s.cwd; c.s.cwd = p; updatePrompt(); c.write("Created and entered " + p, "success");
}, "mkcd projects/demo");
def("appendline", "Files", "appendline <file> <text...>", "Append one line of text to a virtual file.", function (c) {
  var p = path(c.args.shift(), c.s.cwd); if (!p || p === c.s.cwd) return c.err("usage: appendline <file> <text...>");
  if (!isFile(p)) return c.err("appendline: file not found: " + p);
  fsWrite(p, files[p] + (files[p] ? "\n" : "") + c.args.join(" ")); c.write("Appended line to " + p, "success");
}, "appendline notes.txt another note");
def("count", "Text", "count <file>", "Count lines, words, and characters in a virtual file.", function (c) {
  var p = path(c.args[0], c.s.cwd); if (!isFile(p)) return c.err("count: file not found: " + p);
  var t = files[p], lines = t ? t.split(/\r\n|\r|\n/).length : 0, words = (t.match(/\S+/g) || []).length;
  c.write("Lines: " + lines + "\nWords: " + words + "\nCharacters: " + t.length + "\nBytes: " + bytes(t));
}, "count notes.txt");
def("lower", "Text", "lower <file>", "Print a file converted to lowercase.", function (c) {
  var p = path(c.args[0], c.s.cwd); if (!isFile(p)) return c.err("lower: file not found: " + p); c.write(files[p].toLowerCase());
}, "lower notes.txt");
def("upper", "Text", "upper <file>", "Print a file converted to uppercase.", function (c) {
  var p = path(c.args[0], c.s.cwd); if (!isFile(p)) return c.err("upper: file not found: " + p); c.write(files[p].toUpperCase());
}, "upper notes.txt");
def("randompick", "Fun", "randompick <item1> <item2> [...]", "Pick one of the supplied options at random.", function (c) {
  if (c.args.length < 2) return c.err("usage: randompick <item1> <item2> [...]");
  c.write("Selected: " + c.args[Math.floor(Math.random() * c.args.length)], "success");
}, "randompick red blue purple");
def("lorem", "Text", "lorem [paragraphs]", "Generate placeholder text for mockups and editor testing.", function (c) {
  var para = "NOVA is a flexible browser workspace designed for experimenting, creating, and organizing ideas. Customize the environment, build a virtual file structure, and use the terminal to manage your projects.";
  var n = Math.max(1, Math.min(8, parseInt(c.args[0], 10) || 1)); c.write(Array(n).fill(para).join("\n\n"));
}, "lorem 2");
def("syslog", "System", "syslog [clear]", "View or clear the NOVA session event log.", function (c) {
  if ((c.args[0] || "") === "clear") { sysLog = []; c.write("System log cleared.", "success"); return; }
  c.write(sysLog.join("\n") || "(no system events recorded)");
}, "syslog");
def("storage", "System", "storage", "Show virtual storage usage and item counts.", function (c) {
  c.write("Virtual storage: " + humanSize(totalBytes()) + "\nFiles: " + Object.keys(files).length + "\nFolders: " + folders.length + "\nBrowser storage is limited and shared with this site.", "info");
});
def("reloadui", "System", "reloadui", "Refresh NOVA's interface without deleting virtual data.", function (c) {
  c.write("Refreshing the NOVA interface…", "warning"); window.setTimeout(function () { window.location.reload(); }, 250);
});
def("help_74", "Core", "help_74", "Show a short guide to the 7.4.0 additions.", function (c) {
  c.write("NOVA 7.4.0 additions:\nwallpaper <preset>  Change workspace background\nprompt <style>      Change terminal prompt\nfontface <preset>   Change terminal font\nsettitle <name>     Rename terminal tab\nmkalias <n> <cmd>    Create shortcut alias\nunaliasall          Restore default aliases\nmkcd <directory>    Create and enter a folder\nappendline <file>   Append a line\ncount <file>        Count text statistics\nlower/upper <file>  Transform displayed text\nrandompick <items>  Random option picker\nlorem [N]           Placeholder text\nstorage             Storage overview\nsyslog [clear]      Event log\nType help for the complete command index.", "info");
});

/* ======================= Desktop apps ======================= */
var currentSection = "appearance", editorPath = "", editorDirty = false;

function app(id, section) {
  document.querySelectorAll(".app-area").forEach(function (e) { e.classList.add("hidden"); });
  if (id === "settings-area") currentSection = section || currentSection;
  document.querySelectorAll(".nav-button").forEach(function (b) {
    var on = b.dataset.app === id && (!b.classList.contains("nav-sub") || b.dataset.section === currentSection);
    b.classList.toggle("active", on);
  });
  $(id).classList.remove("hidden");
  if (id === "files-area") refreshFiles();
  if (id === "editor-area") refreshEditor();
  if (id === "system-area") updateSystem();
  if (id === "settings-area") { showSection(currentSection); renderSettings(); }
  if (id === "terminal-area") $("command-input").focus();
}

/* ----- Files ----- */
function quoteArg(p) { return /^[\w\/.\-]+$/.test(p) ? p : "'" + p.replace(/'/g, "'\\''") + "'"; }
function renameItem(p) {
  var np = window.prompt("New full path for " + p + ":", p); if (!np) return; np = path(np, "/");
  if (np === p) return;
  if (exists(np)) { window.alert(np + " already exists."); return; }
  if (!isDir(parent(np))) { window.alert("The folder " + parent(np) + " does not exist."); return; }
  if (isDir(p) && under(np, p)) { window.alert("A folder cannot be moved into itself."); return; }
  copyTree(p, np, true); fixCwds(); persist(); eventFS("rename", np);
}
function deleteItem(p, dir) {
  if (dir && descendants(p).length) { window.alert("That folder is not empty. Use the terminal command rm -r to remove it."); return; }
  if (settings.confirmDelete && !window.confirm("Delete " + p + "?")) return;
  if (dir) fsRmdir(p); else fsDelete(p);
  fixCwds(); persist(); eventFS("delete", p);
}
function refreshFiles() {
  var q = ($("file-filter").value || "").toLowerCase(), list = $("file-list"); list.innerHTML = "";
  var items = folders.filter(function (p) { return p !== "/"; }).map(function (p) { return { p: p, d: true }; })
    .concat(Object.keys(files).map(function (p) { return { p: p, d: false }; })).sort(function (a, b) { return a.p.localeCompare(b.p); });
  var shown = items.filter(function (i) { return !q || i.p.toLowerCase().indexOf(q) >= 0; });
  $("file-count").textContent = shown.length + " of " + items.length + " items";
  if (!shown.length) { list.textContent = items.length ? "No items match this filter." : "No files"; return; }
  shown.forEach(function (it) {
    var p = it.p, row = document.createElement("div"); row.className = "file-row";
    var name = document.createElement("div"), label = document.createElement("span"), mt = document.createElement("span");
    label.className = "file-name" + (it.d ? " dir" : ""); label.textContent = p + (it.d ? "/" : "");
    mt.className = "file-meta"; mt.textContent = (it.d ? "folder · " + children(p).length + " items" : humanSize(bytes(files[p])) + " · " + files[p].length + " chars") + " · " + fmtDate(meta[p] || Date.now());
    name.appendChild(label); name.appendChild(mt);
    var acts = document.createElement("div"); acts.className = "file-actions";
    function btn(t, fn) { var b = document.createElement("button"); b.textContent = t; b.onclick = fn; acts.appendChild(b); }
    if (it.d) btn("Open in Terminal", function () { var s = session(); s.oldcwd = s.cwd; s.cwd = p; app("terminal-area"); updatePrompt(); print("cd " + p, "command"); });
    else {
      btn("Edit", function () { openEditor(p); });
      btn("Read", function () { app("terminal-area"); print("cat " + p, "command"); print(files[p]); });
      btn("Download", function () { downloadText(base(p), files[p]); });
    }
    btn("Rename", function () { renameItem(p); });
    btn("Delete", function () { deleteItem(p, it.d); });
    row.appendChild(name); row.appendChild(acts); list.appendChild(row);
  });
}

/* ----- Editor ----- */
function updateEditorCounts() {
  var t = $("editor-content").value;
  $("editor-counts").textContent = editorPath ? t.split(/\s+/).filter(Boolean).length + " words · " + t.length + " chars · " + (t === "" ? 0 : t.split("\n").length) + " lines" : "";
}
function setEditorStatus(msg) { $("editor-status").textContent = msg + (editorDirty ? "  ● unsaved changes" : ""); }
function refreshEditor() {
  var sel = $("editor-file"), old = editorPath || sel.value;
  sel.innerHTML = '<option value="">Select a file...</option>';
  Object.keys(files).sort().forEach(function (p) { var o = document.createElement("option"); o.value = p; o.textContent = p; sel.appendChild(o); });
  if (isFile(old)) sel.value = old; else if (editorPath && !isFile(editorPath)) { editorPath = ""; editorDirty = false; $("editor-content").value = ""; setEditorStatus("The open file was removed."); }
  updateEditorCounts();
}
function loadIntoEditor(p) { editorPath = p; editorDirty = false; $("editor-file").value = p; $("editor-content").value = files[p]; updateEditorCounts(); setEditorStatus("Opened " + p); }
function openEditor(p) { app("editor-area"); refreshEditor(); loadIntoEditor(p); }
function saveEditor(toTerminal) {
  var p = $("editor-file").value;
  if (!isFile(p)) { $("editor-status").textContent = "Select a valid file."; return; }
  fsWrite(p, $("editor-content").value, "editor-save"); editorPath = p; editorDirty = false; updateEditorCounts();
  setEditorStatus("Saved " + p + " at " + new Date().toLocaleTimeString() + " — shared with every terminal session.");
  if (toTerminal) { app("terminal-area"); print("[EDITOR] Saved " + p, "success"); print("Use cat " + p + " to read the latest contents.", "info"); }
}
function confirmDiscard() { return !editorDirty || window.confirm("Discard unsaved changes to " + editorPath + "?"); }

/* ----- System ----- */
function updateSystem() {
  if (!$("system-file-count")) return;
  $("system-file-count").textContent = Object.keys(files).length;
  $("system-folder-count").textContent = folders.length;
  $("system-terminal-count").textContent = sessions.length;
  $("system-storage").textContent = humanSize(totalBytes());
  $("system-uptime").textContent = uptimeText();
  $("system-network").textContent = navigator.onLine ? "online" : "offline";
  $("system-output").textContent = "NOVA OS " + VERSION + "\n" + KERNEL + "\n" + SHELL + "\nStorage: browser localStorage (" + humanSize(totalBytes()) + " of roughly 5 MB used)\nFilesystem: shared VirtualFS\nTerminal sessions: " + sessions.length +
    "\nInstalled (simulated) packages: " + installed().length + "\nAccent: " + settings.accent + " · Density: " + settings.density + "\nBrowser: " + browserName() + "\nStatus: ONLINE";
}

/* ----- Settings ----- */
function showSection(name) {
  currentSection = name;
  document.querySelectorAll(".settings-section").forEach(function (e) { e.classList.toggle("hidden", e.id !== "section-" + name); });
  document.querySelectorAll("#settings-tabs button").forEach(function (b) { b.classList.toggle("active", b.dataset.section === name); });
  document.querySelectorAll(".nav-sub").forEach(function (b) { b.classList.toggle("active", !$("settings-area").classList.contains("hidden") && b.dataset.section === name); });
}
function buildSwatches() {
  var box = $("accent-swatches"); box.innerHTML = "";
  Object.keys(ACCENTS).forEach(function (n) {
    var b = document.createElement("button"); b.className = "swatch"; b.style.background = ACCENTS[n]; b.title = n; b.setAttribute("aria-label", "Accent " + n);
    b.onclick = function () { setSetting("accent", ACCENTS[n]); }; box.appendChild(b);
  });
}
function renderSettings() {
  if (!$("density-select")) return;
  document.querySelectorAll(".swatch").forEach(function (b) { b.classList.toggle("active", b.style.backgroundColor && settings.accent.toLowerCase() === ACCENTS[b.title]); });
  if (colorOk(settings.accent)) $("accent-custom").value = settings.accent;
  $("density-select").value = settings.density; $("term-font").value = settings.termFont; $("editor-font").value = settings.editorFont;
  if ($("wallpaper-select")) $("wallpaper-select").value = settings.wallpaper || "aurora";
  if ($("font-face-select")) $("font-face-select").value = settings.fontFace || "mono";
  if ($("prompt-style-select")) $("prompt-style-select").value = settings.promptStyle || "classic";
  if ($("show-clock")) $("show-clock").checked = settings.showClock !== false;
  $("editor-wrap").checked = !!settings.editorWrap; $("confirm-delete").checked = !!settings.confirmDelete;
  $("storage-usage").textContent = "Virtual files use about " + humanSize(totalBytes()) + " of your browser's roughly 5 MB local storage (" + Object.keys(files).length + " files, " + folders.length + " folders).";
}
function resetWorkspace() {
  if (!window.confirm("Restore the default virtual filesystem and settings? Your virtual files will be replaced.")) return false;
  files = clone(filesDefault); folders = foldersDefault.slice(); meta = {}; var now = Date.now();
  Object.keys(files).concat(folders).forEach(function (p) { meta[p] = now; });
  settings = settingsDefault(); try { localStorage.removeItem(KEYS.history); } catch (e) {}
  sessions.forEach(function (s) { s.cwd = HOME; s.oldcwd = HOME; s.history = []; s.hi = 0; s.env = {}; s.status = 0; });
  persist(); saveSettings(); applySettings(); eventFS("reset", "/");
  editorPath = ""; editorDirty = false; $("editor-content").value = ""; $("editor-status").textContent = ""; updateEditorCounts();
  app("terminal-area"); var s = session(); s.output = []; drawTabs();
  print("Virtual filesystem and settings reset.", "success"); print('Type "help" to get started.'); return true;
}
function doBackup() { downloadText("nova-os-backup-" + tfmt(new Date(), "%F") + ".json", JSON.stringify({ nova: VERSION, files: files, folders: folders, meta: meta, settings: settings }, null, 2), "application/json"); }
function doRestore(s) {
  s = s || session();
  pickFiles(false, ".json,application/json", async function (list) {
    if (!list.length) return;
    try {
      var d = JSON.parse(await readFileText(list[0]));
      if (!d || typeof d.files !== "object" || Array.isArray(d.files) || !Array.isArray(d.folders)) throw new Error("not a NOVA backup file");
      if (!window.confirm("Replace the current workspace with this backup?")) return;
      files = d.files; folders = d.folders; meta = (d.meta && typeof d.meta === "object") ? d.meta : {};
      if (folders.indexOf("/") < 0) folders.unshift("/");
      Object.keys(SYSTEM_FILES).forEach(function (p) { files[p] = SYSTEM_FILES[p]; });
      var now = Date.now(); Object.keys(files).concat(folders).forEach(function (p) { if (typeof meta[p] !== "number") meta[p] = now; });
      if (d.settings && typeof d.settings === "object") settings = Object.assign(settingsDefault(), d.settings);
      fixCwds(); persist(); saveSettings(); applySettings(); eventFS("restore", "/");
      print("Workspace restored from " + list[0].name + ".", "success", s);
    } catch (e) { print("restore: " + (e.message || e), "error", s); }
  });
}

/* ======================= Input handling ======================= */
function lcp(a) { var p = a[0] || ""; a.forEach(function (x) { while (x.indexOf(p) !== 0) p = p.slice(0, -1); }); return p; }
function complete(input, s) {
  var v = input.value, pos = input.selectionStart, before = v.slice(0, pos), tok = /(\S*)$/.exec(before)[1], head = before.slice(0, before.length - tok.length);
  var cmdPos = !/\S/.test(head) || /[;|&]\s*$/.test(head), cands = [];
  if (cmdPos && tok.indexOf("/") < 0) cands = commandNames().concat(Object.keys(settings.aliases)).filter(function (n) { return n.indexOf(tok) === 0; });
  else {
    var i = tok.lastIndexOf("/"), dirTok = i >= 0 ? tok.slice(0, i + 1) : "", pre = tok.slice(i + 1), dir = path(dirTok || ".", s.cwd);
    if (tok === "~") { cands = ["~/"]; }
    else if (isDir(dir)) cands = children(dir).filter(function (c) { return c.name.indexOf(pre) === 0 && (pre || c.name[0] !== "."); }).map(function (c) { return dirTok + c.name + (c.d ? "/" : ""); });
  }
  cands = cands.filter(function (x, i2, a) { return a.indexOf(x) === i2; }).sort();
  if (!cands.length) return;
  var rep = null;
  if (cands.length === 1) rep = cands[0] + (cands[0].slice(-1) === "/" ? "" : " ");
  else { var common = lcp(cands); if (common.length > tok.length) rep = common; else { print(promptText(s) + " " + v, "command", s); print(cands.join("  "), "info", s); } }
  if (rep !== null) { input.value = head + rep + v.slice(pos); var np = (head + rep).length; input.setSelectionRange(np, np); }
}
var commandInput = $("command-input");
function focusCommandInput() {
  var area = $("terminal-area");
  if (area && !area.classList.contains("hidden")) { try { commandInput.focus({ preventScroll: true }); } catch (err) { commandInput.focus(); } }
}
commandInput.addEventListener("keydown", function (e) {
  var s = session(); if (!s) return;
  if (e.key === "Enter") {
    e.preventDefault();
    if (s.running) { print("A command is still running — press Ctrl+C to cancel it.", "warning", s); return; }
    var value = this.value; this.value = ""; var self = this;
    runLine(value, s).then(function () { self.focus(); updateSystem(); });
  }
  else if (e.key === "Tab") { e.preventDefault(); complete(this, s); }
  else if (e.key === "ArrowUp") { e.preventDefault(); if (s.hi > 0) this.value = s.history[--s.hi] || ""; }
  else if (e.key === "ArrowDown") { e.preventDefault(); if (s.hi < s.history.length - 1) this.value = s.history[++s.hi] || ""; else { s.hi = s.history.length; this.value = ""; } }
  else if (e.ctrlKey && e.key.toLowerCase() === "c" && this.selectionStart === this.selectionEnd) { e.preventDefault(); if (s.running) { s.cancel = true; print("^C", "warning", s); } else { print(promptText(s) + " " + this.value + "^C", "command", s); this.value = ""; } }
  else if (e.ctrlKey && e.key.toLowerCase() === "l") { e.preventDefault(); s.output = []; var sc = screen(s); if (sc) sc.innerHTML = ""; }
  else if (e.ctrlKey && e.key.toLowerCase() === "u") { e.preventDefault(); this.value = ""; }
  else if (e.ctrlKey && e.key.toLowerCase() === "d" && !this.value) { e.preventDefault(); if (sessions.length > 1) closeSession(s.id); }
  else if (e.key === "PageUp" || e.key === "PageDown") { e.preventDefault(); var el = screen(s); if (el) el.scrollTop += (e.key === "PageUp" ? -1 : 1) * el.clientHeight * 0.85; }
});
$("terminal-area").addEventListener("click", function (e) { if (e.target.closest("button")) return; if (window.getSelection && String(window.getSelection())) return; focusCommandInput(); });

/* ----- wiring ----- */
document.querySelectorAll("[data-app]").forEach(function (b) { b.onclick = function () { app(b.dataset.app, b.dataset.section); }; });
document.querySelectorAll("#settings-tabs button").forEach(function (b) { b.onclick = function () { showSection(b.dataset.section); }; });
$("new-file").onclick = function () { var p = window.prompt("File path, e.g. /home/nova/test.txt:"); if (p) runLine("touch " + quoteArg(p), session()); };
$("new-folder").onclick = function () { var p = window.prompt("Folder path, e.g. /home/nova/projects:"); if (p) runLine("mkdir " + quoteArg(p), session()); };
$("upload-file").onclick = function () { runLine("upload", session()); };
$("refresh-files").onclick = refreshFiles;
$("file-filter").oninput = refreshFiles;
$("editor-open").onclick = function () { var p = $("editor-file").value; if (isFile(p)) { if (confirmDiscard()) loadIntoEditor(p); } else $("editor-status").textContent = "Select a valid file."; };
$("editor-save").onclick = function () { saveEditor(false); };
$("editor-save-terminal").onclick = function () { saveEditor(true); };
$("editor-revert").onclick = function () { if (isFile(editorPath) && confirmDiscard()) loadIntoEditor(editorPath); };
$("editor-download").onclick = function () { if (editorPath) downloadText(base(editorPath), $("editor-content").value); else $("editor-status").textContent = "Open a file first."; };
$("editor-file").onchange = function () { var p = this.value; if (!confirmDiscard()) { this.value = editorPath; return; } if (isFile(p)) loadIntoEditor(p); else { editorPath = ""; editorDirty = false; $("editor-content").value = ""; $("editor-status").textContent = ""; updateEditorCounts(); } };
$("editor-content").addEventListener("input", function () { if (editorPath) { editorDirty = true; setEditorStatus("Editing " + editorPath); } updateEditorCounts(); });
$("editor-content").addEventListener("keydown", function (e) { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") { e.preventDefault(); saveEditor(false); } });
$("system-neofetch").onclick = function () { app("terminal-area"); runLine("neofetch", session()); };
$("system-open-settings").onclick = function () { app("settings-area", "appearance"); };
$("accent-custom").oninput = function () { setSetting("accent", this.value); };
$("density-select").onchange = function () { setSetting("density", this.value); };
  if ($("wallpaper-select")) $("wallpaper-select").onchange = function () { setSetting("wallpaper", this.value); };
  if ($("font-face-select")) $("font-face-select").onchange = function () { setSetting("fontFace", this.value); };
  if ($("prompt-style-select")) $("prompt-style-select").onchange = function () { setSetting("promptStyle", this.value); updatePrompt(); };
  if ($("show-clock")) $("show-clock").onchange = function () { setSetting("showClock", this.checked); };
$("term-font").onchange = function () { var n = parseInt(this.value, 10); setSetting("termFont", n >= 10 && n <= 24 ? n : settings.termFont); };
$("editor-font").onchange = function () { var n = parseInt(this.value, 10); setSetting("editorFont", n >= 10 && n <= 28 ? n : settings.editorFont); };
$("editor-wrap").onchange = function () { setSetting("editorWrap", this.checked); };
$("confirm-delete").onchange = function () { setSetting("confirmDelete", this.checked); };
$("settings-show-help").onclick = function () { app("terminal-area"); runLine("help", session()); };
$("settings-clear-terminal").onclick = function () { var s = session(); s.output = []; var e = screen(s); if (e) e.innerHTML = ""; app("terminal-area"); };
$("settings-clear-history").onclick = function () { sessions.forEach(function (s) { s.history = []; s.hi = 0; }); try { localStorage.removeItem(KEYS.history); } catch (e) {} $("settings-clear-history").textContent = "History cleared ✓"; setTimeout(function () { $("settings-clear-history").textContent = "Clear command history"; }, 1500); };
$("settings-backup").onclick = doBackup;
$("settings-restore").onclick = function () { doRestore(session()); };
$("settings-reset").onclick = resetWorkspace;
document.addEventListener("nova-filesystem-change", function () { refreshFiles(); refreshEditor(); updateSystem(); renderSettings(); });
function netStatus() { var on = navigator.onLine; $("status-dot").className = on ? "" : "offline"; $("status-text").textContent = on ? "System ready" : "Offline"; updateSystem(); }
window.addEventListener("online", netStatus); window.addEventListener("offline", netStatus);

/* ======================= Start-up ======================= */
load(); log("VirtualFS mounted (" + Object.keys(files).length + " files)");
buildSwatches(); applySettings();
var first = newSession("Terminal 1"); first.history = (readJSON(KEYS.history) || []).slice(-200); first.hi = first.history.length;
sessions.push(first); activeId = first.id;
drawTabs(); refreshFiles(); refreshEditor(); updateSystem(); netStatus();
$("clock").textContent = new Date().toLocaleTimeString();
setInterval(function () { $("clock").textContent = new Date().toLocaleTimeString(); if (!$("system-area").classList.contains("hidden")) updateSystem(); }, 1000);

var n = 0, msg = ["NovaCore " + VERSION + " initializing...", "Loading NovaShell " + VERSION + "...", "Mounting shared VirtualFS...", "Starting desktop...", "NOVA OS online..."];
var timer = setInterval(function () {
  n += 20; $("boot-progress").style.width = n + "%"; $("boot-message").textContent = msg[Math.min(4, Math.floor((n - 1) / 20))];
  if (n >= 100) {
    clearInterval(timer);
    setTimeout(function () {
      $("boot").classList.add("hidden"); $("os").classList.remove("hidden"); app("terminal-area"); log("Desktop started");
      print("NOVA OS " + VERSION, "success");
      print("A lightweight browser desktop with a simulated command shell.", "info");
      print("Files and Editor share the same virtual workspace.");
      print('Try "help", "neofetch", "tree", "todo list", or "man grep". Press Tab to complete.', "info");
    }, 200);
  }
}, 140);
});
