# NOVA OS 7.0

Chromebook-friendly browser OS simulator for VS Code for the Web.

## Files
- index.html
- style.css
- terminal.js
- README.md

## Run
1. Open vscode.dev.
2. Open the NOVA OS folder.
3. Put all four files in the same folder.
4. Open `index.html` in Chrome.

No Node.js, npm, Python, C++, or external libraries are required.

## Live filesystem
Terminal, Files, and Editor share the same simulated VirtualFS.

After editing and saving a file in Editor, the Terminal can immediately read it:
`cat /home/nova/notes.txt`

Terminal changes are also immediately reflected in Files and Editor.

## Storage
The virtual filesystem is saved with browser localStorage. It does not modify real ChromeOS files.

## Commands
`help`, `clear`, `about`, `neofetch`, `whoami`, `hostname`, `uname`, `date`, `uptime`, `ps`, `top`, `reboot`

`pwd`, `ls`, `cd`, `mkdir`, `touch`, `write`, `cat`, `rm`, `tree`

`echo`, `history`, `apps`, `pkg`, `sudo`

## Keyboard
Enter = run command
Up/Down = command history
Tab = autocomplete
Ctrl+L = clear terminal
