document.addEventListener("DOMContentLoaded",function(){
"use strict";

var boot=document.getElementById("boot"),os=document.getElementById("os");
var bootMessage=document.getElementById("boot-message"),bootProgress=document.getElementById("boot-progress");
var clock=document.getElementById("clock"),screen=document.getElementById("screen");
var input=document.getElementById("command-input"),prompt=document.getElementById("prompt");

var defaultFiles={
"/home/nova/welcome.txt":"Welcome to NOVA OS 7.0!\nType help to see commands.",
"/home/nova/notes.txt":"NOVA OS development notes.",
"/system/version.txt":"NOVA OS 7.0 Chromebook Edition",
"/system/kernel.txt":"NovaCore 7.0",
"/system/motd.txt":"NOVA OS online.",
"/etc/hostname":"nova-chromebook",
"/etc/os-release":"NAME=NOVA OS\nVERSION=7.0\nEDITION=Chromebook"
};
var defaultFolders=["/","/home","/home/nova","/system","/etc","/tmp","/dev"];
var files={},folders=[],currentDirectory="/home/nova",history=[],historyIndex=0,startTime=Date.now();

function clone(x){return JSON.parse(JSON.stringify(x))}
function loadData(){
try{
var f=localStorage.getItem("NOVA_OS_FILES"),d=localStorage.getItem("NOVA_OS_FOLDERS");
files=f?JSON.parse(f):clone(defaultFiles);folders=d?JSON.parse(d):defaultFolders.slice();
if(!files||typeof files!=="object"||Array.isArray(files))files=clone(defaultFiles);
if(!Array.isArray(folders))folders=defaultFolders.slice();
}catch(e){files=clone(defaultFiles);folders=defaultFolders.slice()}
}
function saveData(){
try{localStorage.setItem("NOVA_OS_FILES",JSON.stringify(files));localStorage.setItem("NOVA_OS_FOLDERS",JSON.stringify(folders))}
catch(e){print("Browser storage unavailable; changes last only while this page is open.","warning")}
}
function normalizePath(value){
if(!value||value==="~")return"/home/nova";
var result=value.charAt(0)==="/" ? value : currentDirectory+"/"+value;
var parts=result.split("/"),clean=[];
for(var i=0;i<parts.length;i++){if(!parts[i]||parts[i]===".")continue;if(parts[i]===".."){if(clean.length)clean.pop()}else clean.push(parts[i])}
return"/"+clean.join("/")
}
function parentPath(value){var p=normalizePath(value);if(p==="/")return"/";var n=p.lastIndexOf("/");return n<=0?"/":p.substring(0,n)}
function isFile(p){return Object.prototype.hasOwnProperty.call(files,p)}
function isFolder(p){return folders.indexOf(p)!==-1}
function print(text,cls){var line=document.createElement("div");line.className="line"+(cls?" "+cls:"");line.textContent=text===undefined?"":text;screen.appendChild(line);screen.scrollTop=screen.scrollHeight}
function updatePrompt(){prompt.textContent="nova@nova-chromebook:"+(currentDirectory==="/home/nova"?"~":currentDirectory)+"$"}
function fsEvent(type,path){document.dispatchEvent(new CustomEvent("nova-filesystem-change",{detail:{type:type,path:path}}))}
function showApp(id){
var areas=document.querySelectorAll(".app-area"),buttons=document.querySelectorAll(".nav-button");
for(var i=0;i<areas.length;i++)areas[i].classList.add("hidden");
for(var j=0;j<buttons.length;j++)buttons[j].classList.remove("active");
var area=document.getElementById(id);if(area)area.classList.remove("hidden");
for(var k=0;k<buttons.length;k++)if(buttons[k].getAttribute("data-app")===id)buttons[k].classList.add("active");
if(id==="files-area")refreshFiles();if(id==="editor-area")refreshEditorFiles();if(id==="system-area")updateSystem();if(id==="terminal-area")input.focus()
}
function help(){print(`NOVA SHELL 7.0

SYSTEM
  help       Show this help
  clear      Clear terminal
  about      About NOVA OS
  neofetch   System information
  whoami     Current user
  hostname   Computer name
  uname      Kernel information
  date       Current date
  uptime     System uptime
  ps         Processes
  top        System monitor
  reboot     Restart NOVA OS

FILES
  pwd        Current directory
  ls         List files
  cd         Change directory
  mkdir      Create folder
  touch      Create file
  write      Write to file
  cat        Read file
  rm         Delete file
  tree       Show folders

OTHER
  echo       Print text
  history    Command history
  apps       Show applications
  pkg        Package information
  sudo       Simulated administrator command`)}
function listFiles(target){
var folder=normalizePath(target||".");if(!isFolder(folder)){print("ls: directory not found","error");return}
var found=[],keys=Object.keys(files);
for(var i=0;i<keys.length;i++)if(parentPath(keys[i])===folder)found.push(keys[i].substring(keys[i].lastIndexOf("/")+1));
for(var j=0;j<folders.length;j++)if(folders[j]!==folder&&parentPath(folders[j])===folder)found.push(folders[j].substring(folders[j].lastIndexOf("/")+1)+"/");
found.sort();print(found.length?found.join("  "):"(empty)")
}
function makeDirectory(name){
if(!name){print("usage: mkdir <folder>","error");return}
var target=normalizePath(name);
if(isFolder(target)||isFile(target)){print("mkdir: item already exists","error");return}
if(!isFolder(parentPath(target))){print("mkdir: parent does not exist","error");return}
folders.push(target);saveData();fsEvent("mkdir",target);print("Directory created: "+target,"success")
}
function makeFile(name){
if(!name){print("usage: touch <file>","error");return}
var target=normalizePath(name);
if(isFile(target)||isFolder(target)){print("touch: item already exists","error");return}
if(!isFolder(parentPath(target))){print("touch: parent does not exist","error");return}
files[target]="";saveData();fsEvent("create",target);print("File created: "+target,"success")
}
function writeFile(args){
if(args.length<2){print("usage: write <file> <text>","error");return}
var target=normalizePath(args[0]);if(!isFile(target)){print("write: file not found","error");return}
files[target]=args.slice(1).join(" ");saveData();fsEvent("write",target);print("File written: "+target,"success")
}
function catFile(name){
if(!name){print("usage: cat <file>","error");return}
var target=normalizePath(name);if(!isFile(target)){print("cat: file not found","error");return}print(files[target])
}
function removeFile(name){
if(!name){print("usage: rm <file>","error");return}
var target=normalizePath(name);if(!isFile(target)){print("rm: file not found","error");return}
delete files[target];saveData();fsEvent("delete",target);print("File removed: "+target,"success")
}
function showTree(root){
var folder=normalizePath(root||".");if(!isFolder(folder)){print("tree: directory not found","error");return}
print(folder+"/");var children=[],keys=Object.keys(files);
for(var i=0;i<folders.length;i++)if(folders[i]!==folder&&parentPath(folders[i])===folder)children.push(folders[i].substring(folders[i].lastIndexOf("/")+1)+"/");
for(var j=0;j<keys.length;j++)if(parentPath(keys[j])===folder)children.push(keys[j].substring(keys[j].lastIndexOf("/")+1));
children.sort();for(var k=0;k<children.length;k++)print("├── "+children[k])
}
function neofetch(){print(`NOVA OS 7.0

OS: NOVA OS 7.0
Kernel: NovaCore 7.0
Shell: NovaShell 7
Host: nova-chromebook
User: nova
Runtime: Chrome Browser
Platform: Chromebook
Filesystem: LIVE VirtualFS
Status: ONLINE`,"success")}
function uptime(){var s=Math.floor((Date.now()-startTime)/1000),m=Math.floor(s/60);print("NOVA OS uptime: "+m+"m "+(s%60)+"s")}
function execute(line){
line=line.trim();if(!line)return;print(prompt.textContent+" "+line,"command");history.push(line);historyIndex=history.length;
var parts=line.split(/\s+/),cmd=parts.shift().toLowerCase();
switch(cmd){
case"help":help();break;case"clear":screen.innerHTML="";break;case"pwd":print(currentDirectory);break;case"ls":listFiles(parts[0]);break;
case"cd":var nd=normalizePath(parts[0]||"/home/nova");if(!isFolder(nd))print("cd: directory not found","error");else{currentDirectory=nd;updatePrompt()}break;
case"mkdir":makeDirectory(parts[0]);break;case"touch":makeFile(parts[0]);break;case"write":writeFile(parts);break;case"cat":catFile(parts[0]);break;case"rm":removeFile(parts[0]);break;case"tree":showTree(parts[0]);break;
case"echo":print(parts.join(" "));break;case"whoami":print("nova");break;case"hostname":print("nova-chromebook");break;case"uname":print("NovaCore 7.0 x86_64");break;case"date":print(new Date().toString());break;case"uptime":uptime();break;
case"history":if(!history.length)print("(empty)");else for(var h=0;h<history.length;h++)print((h+1)+"  "+history[h]);break;case"neofetch":neofetch();break;
case"ps":print("PID   PROCESS\\n1     NovaCore\\n2     NovaShell\\n3     VirtualFS\\n4     WindowManager\\n5     Terminal");break;
case"top":print("NOVA SYSTEM MONITOR\\n\\nCPU: Browser\\nMemory: Browser managed\\nProcesses: 5\\nNetwork: Browser sandbox\\nStatus: ONLINE");break;
case"apps":print("NOVA APPLICATIONS\\n\\nTerminal\\nFiles\\nEditor\\nSystem\\nSettings");break;
case"pkg":print("NovaPkg 7.0\\n\\nInstalled:\\ncoreutils\\neditor\\nfiles\\nsystem-tools");break;
case"sudo":print("Administrator access is simulated in NOVA OS.","warning");if(parts.length)execute(parts.join(" "));break;
case"about":print("NOVA OS 7.0\\n\\nBrowser-based OS simulator for Chromebook and VS Code for the Web.\\n\\nLive VirtualFS connects Terminal, Files, and Editor.","info");break;
case"reboot":print("Rebooting NOVA OS...","success");setTimeout(function(){location.reload()},700);break;
default:print(cmd+": command not found. Type help.","error")
}}
function refreshFiles(){
var list=document.getElementById("file-list");list.innerHTML="";var keys=Object.keys(files).sort();
if(!keys.length){list.textContent="No files.";return}
for(var i=0;i<keys.length;i++)createFileRow(list,keys[i])
}
function createFileRow(container,path){
var row=document.createElement("div"),name=document.createElement("div"),text=document.createElement("span"),meta=document.createElement("span"),actions=document.createElement("div");
row.className="file-row";text.className="file-name";text.textContent=path;meta.className="file-meta";meta.textContent=files[path].length+" chars";name.appendChild(text);name.appendChild(meta);actions.className="file-actions";
var edit=document.createElement("button");edit.textContent="Edit";edit.addEventListener("click",function(){openEditorFile(path)});
var read=document.createElement("button");read.textContent="Read";read.addEventListener("click",function(){showApp("terminal-area");print("cat "+path,"command");print(files[path])});
var del=document.createElement("button");del.textContent="Delete";del.addEventListener("click",function(){if(window.confirm("Delete "+path+"?"))removeFile(path)});
actions.appendChild(edit);actions.appendChild(read);actions.appendChild(del);row.appendChild(name);row.appendChild(actions);container.appendChild(row)
}
function refreshEditorFiles(){
var select=document.getElementById("editor-file"),previous=select.value;select.innerHTML="";
var empty=document.createElement("option");empty.value="";empty.textContent="Select a file...";select.appendChild(empty);
var keys=Object.keys(files).sort();for(var i=0;i<keys.length;i++){var option=document.createElement("option");option.value=keys[i];option.textContent=keys[i];select.appendChild(option)}
if(isFile(previous))select.value=previous
}
function openEditorFile(path){
showApp("editor-area");refreshEditorFiles();document.getElementById("editor-file").value=path;document.getElementById("editor-content").value=files[path];
document.getElementById("editor-status").textContent="Opened "+path+" • shared with Terminal"
}
function saveEditorFile(toTerminal){
var path=document.getElementById("editor-file").value,content=document.getElementById("editor-content").value,status=document.getElementById("editor-status");
if(!path||!isFile(path)){status.textContent="Select a valid file.";return false}
files[path]=content;saveData();fsEvent("editor-save",path);refreshFiles();refreshEditorFiles();updateSystem();
status.textContent="Saved "+path+" • Terminal updated instantly";
if(toTerminal){showApp("terminal-area");print("[EDITOR] Saved "+path,"success");print("[EDITOR] Terminal now sees the new contents.","info");print("Use: cat "+path)}
return true
}
function updateSystem(){
document.getElementById("system-file-count").textContent=Object.keys(files).length;
document.getElementById("system-folder-count").textContent=folders.length;
document.getElementById("system-output").textContent=`NOVA SYSTEM STATUS

Version: NOVA OS 7.0
Kernel: NovaCore 7.0
Shell: NovaShell 7
Host: nova-chromebook
User: nova
Platform: Chromebook
Runtime: Chrome Browser
Virtual Files: ${Object.keys(files).length}
Virtual Folders: ${folders.length}
Storage: Browser localStorage
Filesystem: LIVE
Status: ONLINE`
}
function resetOS(){
if(!window.confirm("Reset NOVA OS and restore the default virtual filesystem?"))return;
files=clone(defaultFiles);folders=defaultFolders.slice();currentDirectory="/home/nova";history=[];historyIndex=0;saveData();fsEvent("reset","/");
document.getElementById("editor-content").value="";document.getElementById("editor-status").textContent="";showApp("terminal-area");screen.innerHTML="";
print("NOVA OS has been reset.","success");print('Type "help" to get started.','info')
}

input.addEventListener("keydown",function(e){
if(e.key==="Enter"){execute(input.value);input.value="";return}
if(e.key==="ArrowUp"){e.preventDefault();if(historyIndex>0){historyIndex--;input.value=history[historyIndex]};return}
if(e.key==="ArrowDown"){e.preventDefault();if(historyIndex<history.length-1){historyIndex++;input.value=history[historyIndex]}else{historyIndex=history.length;input.value=""};return}
if(e.ctrlKey&&e.key.toLowerCase()==="l"){e.preventDefault();screen.innerHTML="";return}
if(e.key==="Tab"){e.preventDefault();var commands=["help","clear","pwd","ls","cd","mkdir","touch","write","cat","rm","tree","echo","whoami","hostname","uname","date","uptime","history","neofetch","ps","top","apps","pkg","sudo","about","reboot"],matches=commands.filter(function(c){return c.indexOf(input.value)===0});if(matches.length===1)input.value=matches[0]+" ";else if(matches.length>1)print(matches.join("  "),"info")}
});
var nav=document.querySelectorAll("[data-app]");for(var n=0;n<nav.length;n++)nav[n].addEventListener("click",function(){showApp(this.getAttribute("data-app"))});
document.getElementById("refresh-files").addEventListener("click",refreshFiles);
document.getElementById("new-file").addEventListener("click",function(){var n=window.prompt("File path, e.g. /home/nova/test.txt:");if(n){makeFile(n);refreshFiles();refreshEditorFiles();updateSystem()}});
document.getElementById("new-folder").addEventListener("click",function(){var n=window.prompt("Folder path, e.g. /home/nova/projects:");if(n){makeDirectory(n);refreshFiles();updateSystem()}});
document.getElementById("editor-open").addEventListener("click",function(){var p=document.getElementById("editor-file").value;if(!p||!isFile(p)){document.getElementById("editor-status").textContent="Select a valid file.";return}document.getElementById("editor-content").value=files[p];document.getElementById("editor-status").textContent="Opened "+p+" • live filesystem"});
document.getElementById("editor-save").addEventListener("click",function(){saveEditorFile(false)});
document.getElementById("editor-save-terminal").addEventListener("click",function(){saveEditorFile(true)});
document.getElementById("editor-file").addEventListener("change",function(){var p=this.value;if(p&&isFile(p)){document.getElementById("editor-content").value=files[p];document.getElementById("editor-status").textContent="Opened "+p}else{document.getElementById("editor-content").value="";document.getElementById("editor-status").textContent=""}});
document.getElementById("settings-terminal").addEventListener("click",function(){showApp("terminal-area")});
document.getElementById("settings-files").addEventListener("click",function(){showApp("files-area")});
document.getElementById("settings-editor").addEventListener("click",function(){showApp("editor-area")});
document.getElementById("settings-system").addEventListener("click",function(){showApp("system-area")});
document.getElementById("settings-reset").addEventListener("click",resetOS);
document.getElementById("new-terminal").addEventListener("click",function(){print("NOVA OS: Terminal session is already active.","info");input.focus()});
document.addEventListener("nova-filesystem-change",function(e){refreshFiles();refreshEditorFiles();updateSystem()});

loadData();saveData();updatePrompt();refreshFiles();refreshEditorFiles();updateSystem();
function updateClock(){clock.textContent=new Date().toLocaleTimeString()}updateClock();setInterval(updateClock,1000);

var progress=0,messages=["NovaCore 7.0 initializing...","Loading NovaShell 7...","Mounting Live VirtualFS...","Starting NOVA desktop...","NOVA OS online..."];
var bootTimer=setInterval(function(){progress+=20;bootProgress.style.width=progress+"%";bootMessage.textContent=messages[Math.min(messages.length-1,Math.floor((progress-1)/20))];if(progress>=100){clearInterval(bootTimer);setTimeout(function(){boot.classList.add("hidden");os.classList.remove("hidden");showApp("terminal-area");print("NOVA OS 7.0","success");print("NovaCore 7.0 loaded.");print("Live VirtualFS mounted.");print("Files, Editor, and Terminal are connected.");print("");print('Type "help" to get started.','info');input.focus()},300)}},150);
});
